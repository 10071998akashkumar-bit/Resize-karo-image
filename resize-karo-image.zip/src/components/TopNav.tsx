import { Expand, FileImage, Type, Download, PenTool, Crop, ImagePlus, Sparkles, Aperture, FileDigit, Layers, Settings, ShieldCheck } from 'lucide-react';
import type { ToolType } from '../App';
import React from 'react';

interface TopNavProps {
  activeTool: ToolType;
  onToolChange: (tool: ToolType, preset?: string) => void;
}

export function TopNav({ activeTool, onToolChange }: TopNavProps) {
  return (
    <header className="fixed top-0 left-0 right-0 h-[72px] bg-bg-base/80 backdrop-blur-md border-b border-white/5 z-50 px-8 flex items-center justify-between">
      <div className="flex items-center gap-3 cursor-pointer group" onClick={() => onToolChange('home')}>
        <div className="relative w-11 h-11 flex items-center justify-center">
          {/* Orbital Ring - Outer */}
          <div className="absolute inset-0 border border-accent/30 rounded-xl animate-[spin_8s_linear_infinite] group-hover:border-accent group-hover:scale-110 transition-all duration-500" />
          
          {/* Main Icon Container */}
          <div className="relative w-10 h-10 bg-accent rounded-xl flex items-center justify-center shadow-[0_0_25px_rgba(59,130,246,0.4)] group-hover:scale-105 transition-all duration-500 border border-white/20 overflow-hidden">
             {/* Dynamic Scanline */}
             <div className="absolute inset-0 bg-gradient-to-b from-transparent via-white/50 to-transparent h-[200%] -top-[100%] group-hover:top-[100%] transition-all duration-700 ease-in-out pointer-events-none" />
             
             {/* Ghost Layers for 'Unique' Effect */}
             <Aperture className="text-white/20 w-6 h-6 stroke-[2.5px] absolute transition-transform duration-500 group-hover:scale-110 opacity-0 group-hover:opacity-100" />
             <Aperture className="text-accent/40 w-6 h-6 stroke-[2.5px] absolute transition-transform duration-500 group-hover:scale-125 opacity-0 group-hover:opacity-100" />
             
             {/* Primary Icon */}
             <Aperture className="text-white w-6 h-6 stroke-[2.5px] relative z-10 transition-transform duration-500 group-hover:rotate-[60deg]" />
          </div>
        </div>
        <div className="flex flex-col justify-center">
          <div className="flex items-baseline gap-1.5 leading-none">
            <span className="font-heading font-black text-2xl tracking-tighter text-white group-hover:tracking-tighter transition-all duration-500">
              RESIZE
            </span>
            <span className="font-serif italic text-accent text-xl group-hover:translate-x-1 transition-all duration-500">
              Karo
            </span>
          </div>
          <div className="flex items-center gap-2 mt-0.5">
            <div className="h-[2px] flex-1 bg-white/10 group-hover:bg-accent/40 transition-colors duration-500" />
            <span className="text-accent text-[8px] font-mono tracking-[0.4em] font-bold uppercase whitespace-nowrap">
              IMAGE
            </span>
            <div className="h-[2px] w-4 bg-white/10 group-hover:bg-accent/40 transition-colors duration-500" />
          </div>
        </div>
      </div>

      <nav className="hidden lg:flex items-center gap-1">
        <NavLink 
          label="HOME" 
          active={activeTool === 'home'} 
          onClick={() => onToolChange('home')} 
        />
        <NavLink 
          label="RESIZE" 
          active={activeTool === 'resize'} 
          onClick={() => onToolChange('resize')} 
        />
        <NavLink 
          label="CROP" 
          active={activeTool === 'crop'} 
          onClick={() => onToolChange('crop')} 
        />
        <NavLink 
          label="PDF EDITOR" 
          active={activeTool === 'pdfeditor'} 
          onClick={() => onToolChange('pdfeditor')} 
        />
        <NavLink 
          label="SIGNATURE" 
          active={activeTool === 'signature'} 
          onClick={() => onToolChange('signature')} 
        />
      </nav>
      
      <div className="hidden lg:flex items-center gap-4">
        <div className="flex items-center gap-2 bg-white/5 border border-white/10 px-3 py-1.5 rounded-full">
           <Sparkles size={14} className="text-accent" />
           <span className="text-[10px] font-medium text-text-muted uppercase tracking-wider">AI Engines Online</span>
        </div>
        
        <button 
          onClick={() => onToolChange('profile')}
          className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${activeTool === 'profile' ? 'bg-accent text-white' : 'bg-white/5 text-text-muted hover:bg-white/10 hover:text-white border border-white/10'}`}
        >
          <Settings size={18} />
        </button>
      </div>

      <div className="lg:hidden text-[10px] tracking-wider uppercase text-text-muted">
        Menu
      </div>
    </header>
  );
}

function NavLink({ label, active, onClick }: { label: string, active: boolean, onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 text-[11px] font-bold uppercase tracking-[0.15em] transition-all duration-300 rounded-lg ${
        active 
          ? 'text-accent bg-accent/10 shadow-[inset_0_0_10px_rgba(59,130,246,0.1)]' 
          : 'text-text-muted hover:text-white hover:bg-white/5'
      }`}
    >
      {label}
    </button>
  );
}
