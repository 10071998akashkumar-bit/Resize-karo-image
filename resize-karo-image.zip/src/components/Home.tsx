import React from 'react';
import { 
  Maximize, Scissors, Layers, FileDigit, PenTool, Sparkles, 
  FileText, Minimize2, Image as ImageIcon, ArrowRight,
  Cpu, Clock, ShieldCheck, Settings, User, MessageSquare
} from 'lucide-react';
import type { ToolType } from '../App';

interface HomeProps {
  onToolChange: (tool: ToolType) => void;
}

export function Home({ onToolChange }: HomeProps) {
  const tools = [
    { 
      id: 'resize', 
      label: 'Resize Image', 
      desc: 'Change dimensions with precision scaling', 
      icon: <Maximize size={24} />,
      color: 'text-blue-400'
    },
    { 
      id: 'crop', 
      label: 'Crop Image', 
      desc: 'Refine composition with surgical accuracy', 
      icon: <Scissors size={24} />,
      color: 'text-emerald-400'
    },
    { 
      id: 'pdfeditor', 
      label: 'PDF Editor', 
      desc: 'Merge, reorder, and excise PDF pages', 
      icon: <Layers size={24} />,
      color: 'text-purple-400'
    },
    { 
      id: 'removebg', 
      label: 'Background Removal', 
      desc: 'Extract subjects using neural networks', 
      icon: <Sparkles size={24} />,
      color: 'text-amber-400'
    },
    { 
      id: 'pdf2img', 
      label: 'PDF to Image', 
      desc: 'Rasterize PDF pages into JPG sequences', 
      icon: <FileDigit size={24} />,
      color: 'text-rose-400'
    },
    { 
      id: 'compresspdf', 
      label: 'Compress PDF', 
      desc: 'Optimize PDF binary object streams', 
      icon: <Minimize2 size={24} />,
      color: 'text-cyan-400'
    },
    { 
      id: 'img2pdf', 
      label: 'Document Exporter', 
      desc: 'Convert multiple images into PDF books', 
      icon: <FileText size={24} />,
      color: 'text-indigo-400'
    },
    { 
      id: 'signature', 
      label: 'E-Signature', 
      desc: 'Create and embed secured signatures', 
      icon: <PenTool size={24} />,
      color: 'text-fuchsia-400'
    },
    { 
      id: 'profile', 
      label: 'Admin Hub', 
      desc: 'Privileged identity and node configuration', 
      icon: <ShieldCheck size={24} />,
      color: 'text-white'
    },
    { 
      id: 'feedback', 
      label: 'Feedback Hub', 
      desc: 'Suggest improvements and report issues', 
      icon: <MessageSquare size={24} />,
      color: 'text-accent'
    },
  ];

  return (
    <div className="w-full max-w-6xl mx-auto py-8">
      <div className="text-center mb-16">
        <h1 className="hero-heading uppercase tracking-tighter mb-4">
          Resize Karo<br/>Image<span className="serif-italic">&copy;</span>
        </h1>
        <p className="text-text-muted max-w-xl mx-auto text-sm leading-relaxed opacity-80 uppercase tracking-widest font-mono">
          Unified processing node for high-fidelity visual and document deconstruction.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {tools.map((tool) => (
          <div 
            key={tool.id}
            onClick={() => onToolChange(tool.id as ToolType)}
            className="glass-panel p-8 hover:border-accent group cursor-pointer transition-all duration-500 hover:bg-accent/5 flex flex-col items-start h-full group"
          >
            <div className={`w-14 h-14 glass-panel-inner mb-8 flex items-center justify-center transition-all duration-500 group-hover:scale-110 group-hover:shadow-[0_0_20px_rgba(59,130,246,0.3)] bg-white/5 border-white/10 ${tool.color}`}>
              {tool.icon}
            </div>
            <h3 className="text-xl font-bold text-white mb-2 uppercase tracking-wide group-hover:text-accent transition-colors">
              {tool.label}
            </h3>
            <p className="text-text-muted text-xs leading-relaxed mb-8 flex-1 font-medium italic opacity-90">
              {tool.desc}
            </p>
            <div className="flex items-center gap-2 text-accent opacity-0 group-hover:opacity-100 transition-all duration-500 translate-x-[-10px] group-hover:translate-x-0">
               <span className="text-[10px] font-bold uppercase tracking-widest">Initalize</span>
               <ArrowRight size={14} />
            </div>
          </div>
        ))}
      </div>

      <div className="mt-32 mb-16">
        <div className="flex flex-col md:flex-row gap-12">
          <div className="flex-1 glass-panel p-10 relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-24 h-24 bg-accent/5 rounded-bl-full -mr-8 -mt-8 group-hover:bg-accent/10 transition-colors" />
            <Cpu className="text-accent mb-6" size={32} />
            <h4 className="text-lg font-bold text-white uppercase tracking-wider mb-4">Operational Flow</h4>
            <p className="text-text-muted text-xs leading-relaxed font-medium italic opacity-80">
              Client-side WASM processing eliminates server latency. The entire transformation occurs within your local browser threads, ensuring zero upload-wait times and absolute data privacy.
            </p>
          </div>
          
          <div className="flex-1 glass-panel p-10 relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-24 h-24 bg-accent/5 rounded-bl-full -mr-8 -mt-8 group-hover:bg-accent/10 transition-colors" />
            <Clock className="text-emerald-400 mb-6" size={32} />
            <h4 className="text-lg font-bold text-white uppercase tracking-wider mb-4">Time Efficiency</h4>
            <p className="text-text-muted text-xs leading-relaxed font-medium italic opacity-80">
              Unified batch arithmetic and high-concurrency rendering reduce manual workflow overhead by up to 80%. Designed for high-frequency deployments where every second determines impact.
            </p>
          </div>

          <div className="flex-1 glass-panel p-10 relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-24 h-24 bg-accent/5 rounded-bl-full -mr-8 -mt-8 group-hover:bg-accent/10 transition-colors" />
            <ShieldCheck className="text-purple-400 mb-6" size={32} />
            <h4 className="text-lg font-bold text-white uppercase tracking-wider mb-4">Strategic Value</h4>
            <p className="text-text-muted text-xs leading-relaxed font-medium italic opacity-80">
              In a visual-first environment, the fidelity of your assets is non-negotiable. We provide the precision-grade instruments required to maintain brand integrity across all digital touchpoints.
            </p>
          </div>
        </div>
      </div>

      {/* Global Status Footer */}
      <div className="mt-20 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-8 opacity-40 grayscale hover:grayscale-0 transition-all duration-500">
         <div className="flex items-center gap-12">
            <div className="flex flex-col">
               <span className="text-[10px] font-bold uppercase tracking-widest mb-1">Architecture</span>
               <span className="text-xs text-white">Edge-Local Node</span>
            </div>
            <div className="flex flex-col">
               <span className="text-[10px] font-bold uppercase tracking-widest mb-1">Status</span>
               <span className="text-xs text-white">Full Integrity</span>
            </div>
         </div>
         <div className="flex items-center gap-8 text-[10px] font-mono">
            <span>SECURE ENCLAVE ACTIVE</span>
            <span className="w-1.5 h-1.5 bg-accent rounded-full animate-pulse" />
            <span>256-BIT ENCRYPTION</span>
         </div>
      </div>
    </div>
  );
}
