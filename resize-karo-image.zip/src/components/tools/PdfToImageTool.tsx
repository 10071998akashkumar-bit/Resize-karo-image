import React, { useState, useRef } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
import { FileDigit, Download, Layers, RefreshCw, Image as ImageIcon, ChevronRight, FileText } from 'lucide-react';

// Set worker path (using a public CDN for reliable loading in this env)
pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

export function PdfToImageTool() {
  const [file, setFile] = useState<File | null>(null);
  const [images, setImages] = useState<string[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setFile(selectedFile);
      processPdf(selectedFile);
    }
  };

  const processPdf = async (pdfFile: File) => {
    setIsProcessing(true);
    setProgress(0);
    setImages([]);
    
    try {
      const arrayBuffer = await pdfFile.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      const totalPages = pdf.numPages;
      const renderedImages: string[] = [];

      for (let i = 1; i <= totalPages; i++) {
        const page = await pdf.getPage(i);
        const viewport = page.getViewport({ scale: 2.0 }); // High quality scale
        
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        if (!context) continue;

        canvas.height = viewport.height;
        canvas.width = viewport.width;

        await page.render({
          canvasContext: context,
          viewport: viewport,
          canvas: canvas
        } as any).promise;

        renderedImages.push(canvas.toDataURL('image/jpeg', 0.9));
        setProgress(Math.round((i / totalPages) * 100));
      }

      setImages(renderedImages);
    } catch (err) {
      console.error('Error rendering PDF:', err);
      alert('Failed to convert PDF to images. Ensure the file is a valid PDF.');
    } finally {
      setIsProcessing(false);
    }
  };

  const downloadImage = (dataUrl: string, index: number) => {
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = `page-${index + 1}.jpg`;
    link.click();
  };

  const downloadAll = () => {
    images.forEach((img, idx) => {
      setTimeout(() => downloadImage(img, idx), idx * 200);
    });
  };

  return (
    <div className="flex flex-col h-full items-center max-w-6xl mx-auto w-full">
      <div className="text-center mb-12">
        <h2 className="hero-heading uppercase tracking-tight">PDF to Image<br/>Extractor<span className="serif-italic">&copy;</span></h2>
        <p className="text-text-muted mt-4 max-w-lg mx-auto text-sm leading-relaxed opacity-80">
          Deconstruct PDF documents into high-resolution JPG sequences. Native browser-level rasterization.
        </p>
      </div>

      {!file ? (
        <div 
          onClick={() => fileInputRef.current?.click()}
          className="w-full glass-panel p-20 flex flex-col items-center justify-center cursor-pointer hover:border-accent hover:bg-accent/5 transition-all duration-500 group relative overflow-hidden"
        >
          <div className="flex gap-4 mb-8">
            <div className="w-16 h-16 glass-panel-inner flex items-center justify-center text-accent group-hover:scale-110 transition-all duration-500 bg-white/5 border-white/10 ring-8 ring-accent/5">
              <FileDigit size={24} />
            </div>
            <div className="w-16 h-16 glass-panel-inner flex items-center justify-center text-accent group-hover:scale-110 transition-all duration-500 bg-white/5 border-white/10 ring-8 ring-accent/5 delay-75">
              <ChevronRight size={24} />
            </div>
            <div className="w-16 h-16 glass-panel-inner flex items-center justify-center text-accent group-hover:scale-110 transition-all duration-500 bg-white/5 border-white/10 ring-8 ring-accent/5 delay-150">
              <ImageIcon size={24} />
            </div>
          </div>
          <h3 className="text-xl font-bold text-white mb-2 uppercase tracking-[0.2em]">Select PDF Object</h3>
          <p className="text-text-dim text-[10px] font-mono tracking-widest uppercase">Target: Standard / Flattened PDF</p>
        </div>
      ) : (
        <div className="w-full space-y-8">
          {isProcessing ? (
            <div className="glass-panel p-12 flex flex-col items-center justify-center text-center">
              <div className="w-20 h-20 bg-accent/20 rounded-3xl flex items-center justify-center text-accent mb-6 animate-pulse border border-accent/20">
                <RefreshCw size={32} className="animate-spin" />
              </div>
              <h3 className="text-xl font-bold mb-2">Analyzing Node: {progress}%</h3>
              <p className="text-text-dim text-xs uppercase tracking-widest mb-10">Rasterizing page vectors into pixel tensors</p>
              
              <div className="w-full max-w-md h-1.5 bg-white/5 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-accent transition-all duration-300 shadow-[0_0_10px_rgba(59,130,246,0.5)]"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          ) : (
            <div className="glass-panel p-8">
              <div className="flex items-center justify-between mb-10 pb-6 border-b border-white/5">
                <div className="flex items-center gap-6">
                  <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center text-accent border border-accent/10">
                    <Layers size={24} />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white tracking-tight">{images.length} Objects Extracted</h3>
                    <p className="text-text-dim text-[10px] font-mono uppercase tracking-[0.2em]">{file.name}</p>
                  </div>
                </div>
                
                <div className="flex gap-3">
                  <button 
                    onClick={downloadAll}
                    className="btn-primary px-6 flex items-center gap-2"
                  >
                    <Download size={16} />
                    Download All
                  </button>
                  <button 
                    onClick={() => setFile(null)}
                    className="btn-secondary px-6"
                  >
                    Reset
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {images.map((src, idx) => (
                  <div key={idx} className="glass-panel-inner group transition-all duration-500 hover:border-accent/50 overflow-hidden relative rounded-xl h-64 bg-black/20">
                    <img 
                      src={src} 
                      alt={`Page ${idx + 1}`} 
                      className="w-full h-full object-contain p-4 group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4">
                       <div className="flex items-center justify-between">
                          <span className="text-[10px] font-bold text-white uppercase tracking-widest">Page {idx + 1}</span>
                          <button 
                            onClick={() => downloadImage(src, idx)}
                            className="w-8 h-8 rounded-lg bg-accent text-white flex items-center justify-center hover:scale-110 transition-transform"
                          >
                            <Download size={14} />
                          </button>
                       </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
      
      <input 
        type="file" 
        accept="application/pdf" 
        className="hidden" 
        ref={fileInputRef}
        onChange={handleFileChange}
      />
    </div>
  );
}
