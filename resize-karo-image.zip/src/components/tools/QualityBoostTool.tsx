import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, Download, RefreshCw, Maximize2, Zap, Palette, Info, Sun, Undo2, Redo2 } from 'lucide-react';
import { useHistory } from '../../hooks/useHistory';

interface ToolSettings {
  upscale: number;
  sharpen: number;
  brightness: number;
}

const DEFAULT_SETTINGS: ToolSettings = {
  upscale: 2,
  sharpen: 1.5,
  brightness: 100
};

export function QualityBoostTool() {
  const [image, setImage] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showOriginal, setShowOriginal] = useState(false);
  
  const { state: settings, setState: setSettings, undo, redo, canUndo, canRedo } = useHistory<ToolSettings>(DEFAULT_SETTINGS);
  const { upscale, sharpen, brightness } = settings;
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setImage(reader.result as string);
        setResult(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const processImage = async () => {
    if (!image) return;
    setIsProcessing(true);

    // Simulate AI processing time
    setTimeout(() => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        // Apply Sharpness / Vivid filter simulation
        canvas.width = img.width * upscale;
        canvas.height = img.height * upscale;

        // Use high-quality scaling
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';

        // Apply filters
        const contrastVal = 1 + (sharpen - 1) * 0.1;
        const saturateVal = 1 + (sharpen - 1) * 0.05;
        const brightnessVal = brightness / 100;
        ctx.filter = `contrast(${contrastVal}) saturate(${saturateVal}) brightness(${brightnessVal})`;
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        
        // Simple sharpen convolution simulation
        const dataURL = canvas.toDataURL('image/jpeg', 0.95);
        setResult(dataURL);
        setIsProcessing(false);
      };
      img.src = image;
    }, 1500);
  };

  const downloadResult = () => {
    if (!result) return;
    const link = document.createElement('a');
    link.download = 'enhanced_image.jpg';
    link.href = result;
    link.click();
  };

  return (
    <div className="flex flex-col h-full items-center max-w-5xl mx-auto w-full">
      <div className="text-center mb-12">
        <h2 className="hero-heading uppercase tracking-tight">Quality<br/>Enhancer<span className="serif-italic">&copy;</span></h2>
        <p className="text-text-muted mt-4 max-w-lg mx-auto text-sm leading-relaxed opacity-80">
          Restore resolution and clarity using neural interpolation. Optimized for low-light and compressed visual artifacts.
        </p>
      </div>

      {!image ? (
        <div 
          onClick={() => fileInputRef.current?.click()}
          className="w-full glass-panel p-20 flex flex-col items-center justify-center cursor-pointer hover:border-accent hover:bg-accent/5 transition-all duration-500 group relative overflow-hidden"
        >
          <div className="w-20 h-20 glass-panel-inner flex items-center justify-center text-accent mb-8 group-hover:scale-110 transition-all duration-500 ring-8 ring-accent/5">
            <Zap size={32} />
          </div>
          <h3 className="text-xl font-bold text-white mb-2 uppercase tracking-[0.2em]">Upload Here</h3>
          <p className="text-text-dim text-[10px] font-mono tracking-widest uppercase">Formats: JPG / PNG / WEBP</p>
        </div>
      ) : (
        <div className="flex flex-col lg:flex-row gap-8 w-full">
          <div className="flex-1 space-y-6">
             <div className="glass-panel p-6 min-h-[400px] flex items-center justify-center bg-black/40 relative overflow-hidden group">
               <div className="relative overflow-hidden rounded-lg shadow-2xl">
                 {/* Undo/Redo Floating Controls */}
                 <div className="absolute top-4 left-4 flex gap-2 z-30">
                    <button 
                      onClick={undo}
                      disabled={!canUndo}
                      className="p-2 bg-black/60 backdrop-blur-md rounded-lg border border-white/10 text-white disabled:opacity-20 hover:bg-black/80 transition-all"
                      title="Undo"
                    >
                      <Undo2 size={16} />
                    </button>
                    <button 
                      onClick={redo}
                      disabled={!canRedo}
                      className="p-2 bg-black/60 backdrop-blur-md rounded-lg border border-white/10 text-white disabled:opacity-20 hover:bg-black/80 transition-all"
                      title="Redo"
                    >
                      <Redo2 size={16} />
                    </button>
                 </div>

                 <img 
                   src={(result && !showOriginal) ? result : image} 
                   style={{ 
                     filter: (!result || showOriginal) 
                       ? `contrast(${1 + (sharpen - 1) * 0.15}) saturate(${1 + (sharpen - 1) * 0.05}) brightness(${brightness / 100})` 
                       : 'none' 
                   }}
                   className={`max-w-full max-h-[500px] object-contain transition-all duration-700 ${isProcessing ? 'blur-md opacity-50 scale-95' : 'blur-0 opacity-100 scale-100'}`} 
                   alt="Preview" 
                 />

                 {result && !isProcessing && (
                   <div className="absolute top-4 right-4 z-40">
                     <button
                       onMouseDown={() => setShowOriginal(true)}
                       onMouseUp={() => setShowOriginal(false)}
                       onMouseLeave={() => setShowOriginal(false)}
                       onTouchStart={() => setShowOriginal(true)}
                       onTouchEnd={() => setShowOriginal(false)}
                       className={`px-4 py-2 rounded-lg border text-[10px] font-bold uppercase tracking-widest transition-all shadow-lg backdrop-blur-md ${
                         showOriginal 
                           ? 'bg-accent border-accent text-white' 
                           : 'bg-black/60 border-white/10 text-white/70 hover:text-white'
                       }`}
                     >
                       {showOriginal ? 'Showing Original' : 'Hold to Compare'}
                     </button>
                   </div>
                 )}
                 
                 {!result && !isProcessing && (
                   <div className="absolute top-4 right-4 px-2 py-1 bg-accent/20 border border-accent/30 rounded text-[8px] font-bold text-accent uppercase tracking-widest animate-pulse">
                     Live Preview
                   </div>
                 )}
               </div>
               
               {isProcessing && (
                 <div className="absolute inset-0 flex flex-col items-center justify-center z-20">
                    <div className="w-16 h-16 bg-accent/20 rounded-2xl flex items-center justify-center text-accent border border-accent/20 mb-6 animate-pulse">
                       <RefreshCw size={28} className="animate-spin" />
                    </div>
                    <div className="text-[10px] font-bold text-white uppercase tracking-[0.3em] mb-2">Reconstructing Matrix...</div>
                    <div className="text-text-dim text-[8px] uppercase tracking-widest leading-relaxed text-center px-12">Applying neural sharpening to pixel borders.</div>
                 </div>
               )}
            </div>
            
            {!result && !isProcessing && (
              <button 
                onClick={processImage}
                className="btn-primary w-full py-6 flex items-center justify-center gap-3 text-lg"
              >
                <Sparkles size={24} />
                Execute Neural Upscale
              </button>
            )}
          </div>

          <div className="w-full lg:w-[320px] shrink-0 space-y-6">
            <div className="glass-panel p-6 space-y-8">
              <div>
                <div className="text-[10px] uppercase tracking-[0.2em] text-text-dim border-b border-border-dark pb-3 mb-6 flex items-center gap-2">
                  <Maximize2 size={14} className="text-accent" />
                  Upscale Parameters
                </div>
                
                    <div className="space-y-4">
                       <div className="space-y-2 py-2">
                          <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-widest mb-1">
                             <span className="text-text-dim">Resolution Factor</span>
                             <span className="text-white bg-accent/20 px-2 py-0.5 rounded tabular-nums font-mono">{upscale}x</span>
                          </div>
                          <div className="relative h-6 flex items-center">
                            <input 
                              type="range" 
                              min="1" 
                              max="4" 
                              step="1" 
                              value={upscale}
                              onInput={(e: React.FormEvent<HTMLInputElement>) => {
                                setSettings({ ...settings, upscale: parseInt(e.currentTarget.value) }, true);
                                if (result) setResult(null);
                              }}
                              onChange={(e) => {
                                setSettings({ ...settings, upscale: parseInt(e.target.value) });
                                if (result) setResult(null);
                              }}
                              className="w-full accent-accent bg-white/10 h-2 rounded-full outline-none cursor-pointer hover:bg-white/15 transition-all relative z-10 appearance-none selection:bg-transparent"
                            />
                          </div>
                       </div>
                       
                       <div className="space-y-2 py-2">
                          <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-widest mb-1">
                             <span className="text-text-dim">{sharpen > 3 ? 'Deep' : 'Neural'} Sharpness</span>
                             <span className="text-white bg-accent/20 px-2 py-0.5 rounded tabular-nums font-mono">{sharpen.toFixed(1)}</span>
                          </div>
                          <div className="relative h-6 flex items-center">
                            <input 
                              type="range" 
                              min="1" 
                              max="5" 
                              step="0.1" 
                              value={sharpen}
                              onInput={(e: React.FormEvent<HTMLInputElement>) => {
                                setSettings({ ...settings, sharpen: parseFloat(e.currentTarget.value) }, true);
                                if (result) setResult(null);
                              }}
                              onChange={(e) => {
                                setSettings({ ...settings, sharpen: parseFloat(e.target.value) });
                                if (result) setResult(null);
                              }}
                              className="w-full accent-accent bg-white/10 h-2 rounded-full outline-none cursor-pointer hover:bg-white/15 transition-all relative z-10 appearance-none selection:bg-transparent"
                            />
                          </div>
                       </div>
    
                       <div className="space-y-2 py-2">
                          <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-widest mb-1">
                             <span className="text-text-dim flex items-center gap-2"><Sun size={10} className="text-accent" /> Luminance</span>
                             <span className="text-white bg-accent/20 px-2 py-0.5 rounded tabular-nums font-mono">{brightness}%</span>
                          </div>
                          <div className="relative h-6 flex items-center">
                            <input 
                              type="range" 
                              min="50" 
                              max="200" 
                              step="1" 
                              value={brightness}
                              onInput={(e: React.FormEvent<HTMLInputElement>) => {
                                setSettings({ ...settings, brightness: parseInt(e.currentTarget.value) }, true);
                                if (result) setResult(null);
                              }}
                              onChange={(e) => {
                                setSettings({ ...settings, brightness: parseInt(e.target.value) });
                                if (result) setResult(null);
                              }}
                              className="w-full accent-accent bg-white/10 h-2 rounded-full outline-none cursor-pointer hover:bg-white/15 transition-all relative z-10 appearance-none selection:bg-transparent"
                            />
                          </div>
                       </div>
                    </div>
              </div>

              <div className="pt-6 space-y-4">
                 <button 
                   onClick={downloadResult}
                   disabled={!result}
                   className="btn-primary w-full disabled:opacity-20 flex items-center justify-center gap-3"
                 >
                   <Download size={18} />
                   Download Enhanced
                 </button>
                 <button 
                   onClick={() => { setImage(null); setResult(null); }}
                   className="btn-secondary w-full"
                 >
                   Discard Image
                 </button>
              </div>

              <div className="p-4 bg-accent/5 border border-accent/20 rounded-2xl">
                 <div className="flex gap-3 text-accent mb-3">
                    <Info size={16} />
                    <span className="text-[10px] font-bold uppercase tracking-widest">Studio Engine</span>
                 </div>
                 <p className="text-[9px] text-text-muted leading-relaxed uppercase tracking-tighter opacity-70">
                   Resolution enhancement uses bilinear interpolation and color restructuring to simulate high-definition output. Processed entirely on-device.
                 </p>
              </div>
            </div>
          </div>
        </div>
      )}

      <input 
        type="file" 
        accept="image/*" 
        className="hidden" 
        ref={fileInputRef}
        onChange={handleFileChange}
      />
    </div>
  );
}
