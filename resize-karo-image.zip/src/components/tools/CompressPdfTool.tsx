import React, { useState, useRef } from 'react';
import { PDFDocument } from 'pdf-lib';
import { Minimize2, Download, RefreshCw, FileDigit, Info, CheckCircle, FileText } from 'lucide-react';

export function CompressPdfTool() {
  const [file, setFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<Uint8Array | null>(null);
  const [stats, setStats] = useState<{ original: number; compressed: number } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setFile(selectedFile);
      setResult(null);
      setStats(null);
    }
  };

  const compressPdf = async () => {
    if (!file) return;
    setIsProcessing(true);

    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdfDoc = await PDFDocument.load(arrayBuffer, { ignoreEncryption: true });
      
      // Basic optimization in pdf-lib:
      // 1. Flattening forms if any
      // 2. Using object streams
      const compressedBytes = await pdfDoc.save({
        useObjectStreams: true,
        updateFieldAppearances: false
      });

      setResult(compressedBytes);
      setStats({
        original: file.size,
        compressed: compressedBytes.length
      });
    } catch (err) {
      console.error('Compression error:', err);
      alert('Failed to optimize PDF.');
    } finally {
      setIsProcessing(false);
    }
  };

  const downloadResult = () => {
    if (!result) return;
    const blob = new Blob([result], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `optimized_${file?.name}`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="flex flex-col h-full items-center max-w-4xl mx-auto w-full">
      <div className="text-center mb-12">
        <h2 className="hero-heading uppercase tracking-tight">PDF Optimizer<br/>Engine<span className="serif-italic">&copy;</span></h2>
        <p className="text-text-muted mt-4 max-w-lg mx-auto text-sm leading-relaxed opacity-80">
          Streamline PDF binaries by restructuring internal object streams. Native browser-level optimization.
        </p>
      </div>

      {!file ? (
        <div 
          onClick={() => fileInputRef.current?.click()}
          className="w-full glass-panel p-20 flex flex-col items-center justify-center cursor-pointer hover:border-accent hover:bg-accent/5 transition-all duration-500 group relative overflow-hidden"
        >
          <div className="w-16 h-16 glass-panel-inner flex items-center justify-center text-accent mb-8 group-hover:scale-110 transition-all duration-500 ring-8 ring-accent/5">
            <Minimize2 size={24} />
          </div>
          <h3 className="text-xl font-bold text-white mb-2 uppercase tracking-[0.2em]">Load PDF Artifact</h3>
          <p className="text-text-dim text-[10px] font-mono tracking-widest uppercase">Max recommended: 50MB for local node</p>
        </div>
      ) : (
        <div className="w-full glass-panel p-10">
          <div className="flex items-center gap-8 mb-12">
             <div className="w-20 h-24 bg-accent/10 border border-accent/20 rounded-2xl flex items-center justify-center text-accent relative">
                <FileText size={32} strokeWidth={1} />
                <div className="absolute -bottom-2 -right-2 bg-accent text-white p-1 rounded-full border-4 border-bg-base">
                   {result ? <CheckCircle size={14} /> : <div className="w-3.5 h-3.5 border-2 border-white/20 border-t-white animate-spin rounded-full invisible" />}
                </div>
             </div>
             <div className="flex-1">
                <h3 className="text-2xl font-bold text-white mb-1 truncate">{file.name}</h3>
                <div className="flex gap-4 text-[10px] font-mono uppercase tracking-widest text-text-dim">
                   <span>Size: {formatSize(file.size)}</span>
                   <span className="text-accent/40">|</span>
                   <span>Type: Application/PDF</span>
                </div>
             </div>
          </div>

          {stats && (
            <div className="grid grid-cols-2 gap-4 mb-10">
               <div className="glass-panel-inner p-6">
                  <div className="text-[10px] font-bold text-text-dim uppercase tracking-widest mb-2">Architectural Gain</div>
                  <div className="text-3xl font-black text-accent">-{Math.max(0, Math.round((1 - stats.compressed / stats.original) * 100))}%</div>
               </div>
               <div className="glass-panel-inner p-6">
                  <div className="text-[10px] font-bold text-text-dim uppercase tracking-widest mb-2">Final Node Size</div>
                  <div className="text-3xl font-black text-white">{formatSize(stats.compressed)}</div>
               </div>
            </div>
          )}

          <div className="flex flex-col sm:flex-row gap-4">
             {!result ? (
               <button 
                 onClick={compressPdf}
                 disabled={isProcessing}
                 className="btn-primary flex-1 py-6 flex items-center justify-center gap-3 text-lg relative overflow-hidden"
               >
                 {isProcessing ? (
                   <>
                     <RefreshCw className="animate-spin" size={24} />
                     Optimizing...
                   </>
                 ) : (
                   <>
                     <Minimize2 size={24} />
                     Execute Optimization
                   </>
                 )}
               </button>
             ) : (
               <button 
                 onClick={downloadResult}
                 className="btn-primary flex-1 py-6 flex items-center justify-center gap-3 text-lg"
               >
                 <Download size={24} />
                 Download Optimized PDF
               </button>
             )}
             <button 
               onClick={() => { setFile(null); setResult(null); setStats(null); }}
               className="btn-secondary sm:w-48 text-[10px] uppercase font-bold tracking-[0.2em]"
             >
               Purge Memory
             </button>
          </div>

          <div className="mt-10 p-6 bg-white/2 border border-white/5 rounded-2xl flex gap-4 items-start">
             <div className="text-accent shrink-0 mt-1"><Info size={16} /></div>
             <p className="text-[10px] text-text-muted leading-relaxed uppercase tracking-wider opacity-60">
               Browser-side optimization primarily restructures internal object streams and removes metadata bloat. For heavy image compression, consider converting to JPG first or using server-side post-processing.
             </p>
          </div>
        </div>
      )}

      <input 
        type="file" 
        accept="application/pdf" 
        className="hidden" 
        ref={fileInputRef}
        onChange={handleFileChange}
      />
    </div>
  );
}
