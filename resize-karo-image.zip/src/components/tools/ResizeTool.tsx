import React, { useState, useRef, useEffect } from 'react';
import { Upload, ArrowRight, Download, RefreshCw, AlertCircle, BookOpen, CheckCircle2, Scissors, Image as ImageIcon, PenTool, FileText, Folder, GitCommit, GitBranch, FileDown, Undo2, Redo2 } from 'lucide-react';
import { jsPDF } from 'jspdf';
import { useHistory } from '../../hooks/useHistory';

interface PresetConfig {
  width?: number;
  height?: number;
  unit: 'pixels' | 'cm' | 'inch';
  maxSizeKb?: number;
  compressAlso?: boolean;
}

interface ResizeSettings {
  unit: 'pixels' | 'cm' | 'inch';
  width: string;
  height: string;
  dpi: number;
  maintainAspect: boolean;
  compressAlso: boolean;
  targetSizeKb: string;
  format: 'image/jpeg' | 'image/png' | 'image/webp' | 'application/pdf';
}

const DEFAULT_SETTINGS: ResizeSettings = {
  unit: 'pixels',
  width: '',
  height: '',
  dpi: 300,
  maintainAspect: true,
  compressAlso: false,
  targetSizeKb: '',
  format: 'image/jpeg'
};

const EXAM_PRESETS: Record<string, PresetConfig> = {
  'ssc-photo': { width: 3.5, height: 4.5, unit: 'cm', maxSizeKb: 50 },
  'ssc-signature': { width: 4.0, height: 2.0, unit: 'cm', maxSizeKb: 20 },
  'railway-photo': { width: 240, height: 320, unit: 'pixels', maxSizeKb: 50 },
  'railway-signature': { width: 140, height: 60, unit: 'pixels', maxSizeKb: 40 },
  'banking-photo': { width: 200, height: 230, unit: 'pixels', maxSizeKb: 50 },
  'banking-signature': { width: 140, height: 60, unit: 'pixels', maxSizeKb: 20 },
  'banking-thumb': { width: 240, height: 240, unit: 'pixels', maxSizeKb: 50 },
  'banking-declaration': { width: 800, height: 400, unit: 'pixels', maxSizeKb: 100 },
  'state-photo': { width: 3.5, height: 4.5, unit: 'cm', maxSizeKb: 100 },
  'state-signature': { width: 3.5, height: 1.5, unit: 'cm', maxSizeKb: 50 },
  'id-card': { width: 8.5, height: 5.5, unit: 'cm', maxSizeKb: 200 },
  'passport-global': { width: 2, height: 2, unit: 'inch', maxSizeKb: 300 },
  'compress-only': { unit: 'pixels', compressAlso: true }
};

export function ResizeTool({ preset }: { preset: string | null }) {
  const [file, setFile] = useState<File | null>(null);
  const [previewSrc, setPreviewSrc] = useState<string>('');
  const [originalInfo, setOriginalInfo] = useState({ width: 0, height: 0, sizeKb: 0 });
  const [newInfo, setNewInfo] = useState({ width: 0, height: 0, sizeKb: 0 });
  
  const { state: settings, setState: setSettings, undo, redo, canUndo, canRedo, resetHistory } = useHistory<ResizeSettings>(DEFAULT_SETTINGS);
  const { unit, width, height, dpi, maintainAspect, compressAlso, targetSizeKb, format } = settings;
  
  const [activePreset, setActivePreset] = useState<string | null>(preset);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);

  // Apply preset on mount or when it changes from props
  useEffect(() => {
    if (preset && EXAM_PRESETS[preset]) {
      applyPreset(preset);
    }
  }, [preset]);

  const applyPreset = (presetId: string) => {
    const config = EXAM_PRESETS[presetId];
    if (!config) return;
    
    setActivePreset(presetId);
    
    const newSettings: ResizeSettings = {
      ...settings,
      unit: config.unit,
      format: 'image/jpeg'
    };
    
    if (config.width && config.height) {
      newSettings.width = config.width.toString();
      newSettings.height = config.height.toString();
      newSettings.maintainAspect = false;
    }
    
    if (config.maxSizeKb) {
      newSettings.compressAlso = true;
      newSettings.targetSizeKb = config.maxSizeKb.toString();
    } else if (config.compressAlso) {
      newSettings.compressAlso = true;
    } else {
      newSettings.compressAlso = false;
      newSettings.targetSizeKb = '';
    }
    
    setSettings(newSettings);
    
    // Recalculate dimensions if image exists
    setTimeout(calculateNewDimensions, 50);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (!selected) return;
    
    setFile(selected);
    const url = URL.createObjectURL(selected);
    setPreviewSrc(url);
    
    const img = new Image();
    img.onload = () => {
      setOriginalInfo({
        width: img.width,
        height: img.height,
        sizeKb: Math.round(selected.size / 1024)
      });
      imgRef.current = img;
      
      // Auto-fill width/height if not set, or update preview
      if (!width && !height && !activePreset) {
        setSettings({
          ...settings,
          width: img.width.toString(),
          height: img.height.toString(),
          unit: 'pixels'
        });
      }
      
      // Simulate new size initially
      setTimeout(calculateNewDimensions, 100);
    };
    img.src = url;
  };

  const getPixels = (val: number, currentUnit: string) => {
    if (currentUnit === 'cm') return val * (dpi / 2.54);
    if (currentUnit === 'inch') return val * dpi;
    return val;
  };

  const calculateNewDimensions = () => {
    if (!imgRef.current || (!width && !height)) return;
    
    const w = parseFloat(width) || 0;
    const h = parseFloat(height) || 0;
    
    let pxWidth = Math.round(getPixels(w, unit));
    let pxHeight = Math.round(getPixels(h, unit));
    
    // Fallback if one is missing and aspect ratio is maintained
    if (maintainAspect && imgRef.current) {
        const ratio = imgRef.current.width / imgRef.current.height;
        if (pxWidth > 0 && pxHeight === 0) pxHeight = Math.round(pxWidth / ratio);
        if (pxHeight > 0 && pxWidth === 0) pxWidth = Math.round(pxHeight * ratio);
    }
    
    // Estimate new size (very rough)
    let sizeEstimate = originalInfo.sizeKb;
    if (pxWidth > 0 && pxHeight > 0) {
      const areaRatio = (pxWidth * pxHeight) / (originalInfo.width * originalInfo.height || 1);
      sizeEstimate = Math.round(originalInfo.sizeKb * areaRatio);
    }
    
    if (compressAlso && targetSizeKb) {
      sizeEstimate = Math.min(sizeEstimate, parseFloat(targetSizeKb) * 0.9);
    }

    setNewInfo({ width: pxWidth, height: pxHeight, sizeKb: Math.max(1, sizeEstimate) });
  };

  // Recalculate when inputs change
  useEffect(() => {
    calculateNewDimensions();
  }, [width, height, unit, dpi, maintainAspect, compressAlso, targetSizeKb]);

  const handleWidthChange = (val: string) => {
    const nextSettings = { ...settings, width: val };
    setActivePreset(null);
    if (maintainAspect && imgRef.current && val) {
      const w = parseFloat(val);
      const ratio = imgRef.current.width / imgRef.current.height;
      nextSettings.height = (w / ratio).toFixed(unit === 'pixels' ? 0 : 2);
    }
    setSettings(nextSettings);
  };

  const handleHeightChange = (val: string) => {
    const nextSettings = { ...settings, height: val };
    setActivePreset(null);
    if (maintainAspect && imgRef.current && val) {
      const h = parseFloat(val);
      const ratio = imgRef.current.width / imgRef.current.height;
      nextSettings.width = (h * ratio).toFixed(unit === 'pixels' ? 0 : 2);
    }
    setSettings(nextSettings);
  };

  const handleDownload = async () => {
    if (!imgRef.current || !file) return;

    const canvas = document.createElement('canvas');
    let targetW = newInfo.width || originalInfo.width;
    let targetH = newInfo.height || originalInfo.height;

    canvas.width = targetW;
    canvas.height = targetH;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Fill white bg for jpegs to prevent black background on transparent pngs
    if (format === 'image/jpeg') {
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }
    
    ctx.drawImage(imgRef.current, 0, 0, targetW, targetH);
    
    if (format === 'application/pdf') {
      const pdf = new jsPDF({
        orientation: targetW > targetH ? 'landscape' : 'portrait',
        unit: 'px',
        format: [targetW, targetH]
      });
      pdf.addImage(canvas.toDataURL('image/jpeg', 0.95), 'JPEG', 0, 0, targetW, targetH);
      pdf.save(`resized_${file.name.replace(/\.[^/.]+$/, "")}.pdf`);
      return;
    }

    let quality = 0.92;
    let dataUrl = canvas.toDataURL(format, quality);
    
    // Basic compression loop
    if (compressAlso && targetSizeKb) {
      const targetBytes = parseFloat(targetSizeKb) * 1024;
      let minQ = 0.1, maxQ = 1.0;
      let iterations = 0;
      
      while (iterations < 8) {
        quality = (minQ + maxQ) / 2;
        dataUrl = canvas.toDataURL(format, quality);
        
        // Approx base64 to bytes
        const sizeBytes = dataUrl.length * 0.75;
        
        if (sizeBytes > targetBytes) {
          maxQ = quality;
        } else {
          minQ = quality;
        }
        iterations++;
      }
    }

    const link = document.createElement('a');
    link.download = `resized_${file.name.replace(/\.[^/.]+$/, "")}.${format.split('/')[1]}`;
    link.href = dataUrl;
    link.click();
  };

  if (!file) {
    return (
      <div className="flex flex-col h-full items-center max-w-5xl mx-auto w-full">
        <div className="text-center mb-12">
          <h2 className="hero-heading">Image size<br/>changer<span className="serif-italic">&copy;</span></h2>
          <p className="text-text-muted mt-4 max-w-lg mx-auto text-sm">Professional grade processing for web assets, architectural documents, and secure identifications.</p>
        </div>

        <div 
          onClick={() => fileInputRef.current?.click()}
          className="w-full glass-panel active:scale-[0.99] p-16 flex flex-col items-center justify-center cursor-pointer hover:border-accent hover:bg-accent/5 transition-all duration-500 group relative overflow-hidden"
        >
          <div className="flex gap-4 mb-8">
            {[Scissors, ImageIcon, PenTool].map((Icon, idx) => (
              <div key={idx} className="w-16 h-16 glass-panel-inner flex items-center justify-center text-accent group-hover:scale-110 group-hover:rotate-6 transition-all duration-500 bg-white/5 border-white/10">
                <Icon size={24} />
              </div>
            ))}
          </div>
          <h3 className="text-xl font-bold text-white mb-2">Upload here</h3>
          <p className="text-text-dim text-xs font-mono uppercase tracking-[0.2em]">Universal Payload: JPG / PNG / WEBP</p>
        </div>
        
        <input 
          type="file" 
          accept="image/png, image/jpeg, image/webp" 
          className="hidden" 
          ref={fileInputRef}
          onChange={handleFileChange}
        />

        <div className="mt-16 w-full max-w-4xl">
           <div className="flex items-center gap-4 mb-6">
              <span className="text-[11px] font-bold text-text-dim uppercase tracking-[0.2em]">Optimization Presets</span>
              <div className="flex-1 h-px bg-white/5" />
           </div>
           <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
             {['ssc-photo', 'railway-photo', 'banking-photo', 'state-signature'].map((pid, idx) => (
                <div key={pid} onClick={() => { applyPreset(pid); fileInputRef.current?.click(); }}
                     className="glass-panel-inner p-6 hover:border-accent hover:bg-accent/5 cursor-pointer transition-all duration-300 group flex flex-col items-start justify-between h-32 relative">
                   <div className="text-accent/40 font-mono text-[10px]">[ 0{idx + 1} ]</div>
                   <div className="font-bold text-xs uppercase tracking-widest text-text-muted group-hover:text-white transition-colors">
                     {pid.replace('-', ' ')}
                   </div>
                </div>
             ))}
           </div>
        </div>

      </div>
    );
  }

  return (
    <div className="flex flex-col lg:flex-row gap-6 h-full max-w-6xl mx-auto w-full">
      {/* Left side: Preview & Original Info */}
      <div className="flex-1 flex flex-col">
        <div className="glass-panel p-6 flex flex-col justify-between flex-1 min-h-[400px]">
          <div className="relative max-w-full max-h-[400px] flex items-center justify-center border border-border-dark bg-diagonal-stripes p-4 mb-6">
             {/* Undo/Redo Floating Controls */}
             <div className="absolute top-4 left-4 flex gap-2 z-30">
                <button 
                  onClick={undo}
                  disabled={!canUndo}
                  className="p-2 bg-black/60 backdrop-blur-md rounded-lg border border-white/10 text-white disabled:opacity-20 hover:bg-black/80 transition-all font-bold"
                  title="Undo"
                >
                  <Undo2 size={16} />
                </button>
                <button 
                  onClick={redo}
                  disabled={!canRedo}
                  className="p-2 bg-black/60 backdrop-blur-md rounded-lg border border-white/10 text-white disabled:opacity-20 hover:bg-black/80 transition-all font-bold"
                  title="Redo"
                >
                  <Redo2 size={16} />
                </button>
             </div>

             <img src={previewSrc} alt="Preview" className="max-w-full max-h-[360px] object-contain border border-border-dark bg-surface shadow-2xl shadow-black" />
          </div>
          
          <div className="w-full bg-surface border border-border-light p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
             <div>
               <div className="stat-label">Original Asset</div>
               <div className="stat-value m-0">{originalInfo.width} &times; {originalInfo.height} px</div>
               <div className="text-[10px] text-text-muted mt-1 font-mono">{originalInfo.sizeKb} KB</div>
             </div>
             
             <div className="text-right">
              <div className="stat-label">Output Estimate</div>
              <div className="stat-value text-accent m-0 whitespace-nowrap">
                {newInfo.width} &times; {newInfo.height} px
              </div>
              {unit !== 'pixels' && (
                <div className="text-[9px] text-text-dim font-mono uppercase">
                  ({width || '0'} &times; {height || '0'} {unit})
                </div>
              )}
              <div className="text-[10px] text-text-muted mt-1 font-mono">~{newInfo.sizeKb} KB</div>
            </div>
          </div>
        </div>
      </div>

      {/* Right side: Controls */}
      <div className="w-full lg:w-[350px] shrink-0">
        <div className="glass-panel p-6 space-y-6 sticky top-6">
           <div>
             <div className="text-[10px] uppercase tracking-[0.2em] text-text-dim border-b border-border-dark pb-2 mb-4">Core Settings</div>
             
             {/* Unit Selection */}
             <div className="flex border border-border-light mb-5">
               {['pixels', 'cm', 'inch'].map((u, i) => (
                 <button
                   key={u}
                   onClick={() => { setSettings({ ...settings, unit: u as any }); setActivePreset(null); }}
                   className={`flex-1 py-2 text-[10px] tracking-wider uppercase transition-colors border-r border-border-light last:border-r-0 ${
                     unit === u ? 'bg-white text-black font-bold' : 'text-text-muted hover:text-white bg-bg-base'
                   }`}
                 >
                   {u}
                 </button>
               ))}
             </div>

             {/* Dimensions */}
             <div className="flex items-end gap-3 mb-5">
               <div className="flex-1">
                 <label className="text-[9px] uppercase tracking-widest text-text-muted mb-1 block">Width ({unit})</label>
                 <input 
                   type="number" 
                   value={width} 
                   onChange={(e) => handleWidthChange(e.target.value)}
                   className="input-base w-full outline-none" 
                   placeholder="AUTO"
                 />
               </div>
               <div className="text-text-dim pb-3 font-mono">&times;</div>
               <div className="flex-1">
                 <label className="text-[9px] uppercase tracking-widest text-text-muted mb-1 block">Height ({unit})</label>
                 <input 
                   type="number" 
                   value={height} 
                   onChange={(e) => handleHeightChange(e.target.value)}
                   className="input-base w-full outline-none" 
                   placeholder="AUTO"
                 />
               </div>
             </div>

             {/* Print Readiness - DPI Control */}
             <div className="mb-6 p-4 bg-white/5 border border-white/10 rounded-lg">
                <div className="flex justify-between items-center mb-3">
                  <span className="text-[9px] uppercase tracking-[0.2em] text-accent font-bold">Print Resolution</span>
                  <div className="flex items-center gap-2">
                    <input 
                      type="number"
                      value={dpi}
                      onChange={(e) => setSettings({ ...settings, dpi: parseInt(e.target.value) || 72 })}
                      className="w-16 bg-black/40 border border-white/10 rounded px-2 py-1 text-[11px] font-mono font-bold text-white text-right focus:border-accent outline-none tabular-nums"
                    />
                    <span className="text-[9px] font-bold text-text-dim uppercase tracking-widest">DPI</span>
                  </div>
                </div>
                <input 
                   type="range" 
                   min="72" 
                   max="600" 
                   step="1" 
                   value={dpi}
                   onInput={(e: React.FormEvent<HTMLInputElement>) => setSettings({ ...settings, dpi: parseInt(e.currentTarget.value) }, true)}
                   onChange={(e) => setSettings({ ...settings, dpi: parseInt(e.target.value) })}
                   className="w-full accent-accent h-1.5 bg-white/10 rounded-full mb-4 cursor-pointer"
                />
                <div className="flex gap-2 text-[8px] font-bold uppercase tracking-widest">
                   {[72, 300, 600].map(val => (
                     <button 
                       key={val}
                       onClick={() => setSettings({ ...settings, dpi: val })}
                       className={`flex-1 py-1.5 border rounded transition-all ${dpi === val ? 'border-accent bg-accent/20 text-accent' : 'border-white/5 bg-transparent text-text-dim hover:text-white'}`}
                     >
                       {val === 72 ? 'Web' : val === 300 ? 'Print' : 'HD'}
                     </button>
                   ))}
                </div>
             </div>

             {/* Aspect Ratio */}
             <label className="flex items-center gap-3 text-[10px] uppercase tracking-wider text-text-main cursor-pointer group">
               <div className={`w-4 h-4 border transition-colors flex items-center justify-center ${maintainAspect ? 'bg-accent border-accent' : 'border-border-light group-hover:border-accent'}`}>
                  {maintainAspect && <div className="w-2 h-2 bg-black" />}
               </div>
               <input 
                 type="checkbox" 
                 checked={maintainAspect}
                 onChange={(e) => { setSettings({ ...settings, maintainAspect: e.target.checked }); setActivePreset(null); }}
                 className="hidden"
               />
               Maintain Aspect
             </label>
           </div>
           
           <div>
             <div className="text-[10px] uppercase tracking-[0.2em] text-text-dim border-b border-border-dark pb-2 mb-4 mt-6">Compression</div>
             
             {/* Compression */}
             <label className="flex items-center gap-3 text-[10px] uppercase tracking-wider text-text-main cursor-pointer group mb-4">
               <div className={`w-4 h-4 border transition-colors flex items-center justify-center ${compressAlso ? 'bg-accent border-accent' : 'border-border-light group-hover:border-accent'}`}>
                  {compressAlso && <div className="w-2 h-2 bg-black" />}
               </div>
               <input 
                 type="checkbox" 
                 checked={compressAlso}
                 onChange={(e) => { setSettings({ ...settings, compressAlso: e.target.checked }); setActivePreset(null); }}
                 className="hidden"
               />
               Reduce Filesize
             </label>
             
             {compressAlso && (
                <div className="pl-7 mb-2">
                  <label className="text-[9px] uppercase tracking-widest text-text-muted mb-1 block font-bold text-accent">Target Size (KB)</label>
                  <input 
                    type="number" 
                    value={targetSizeKb} 
                    onChange={(e) => { setSettings({ ...settings, targetSizeKb: e.target.value }); setActivePreset(null); }}
                    className="input-base w-full border-accent/30" 
                    placeholder="E.G. 50"
                  />
                  <div className="text-[8px] text-text-dim mt-1 uppercase">REQUIRED MAX SIZE</div>
                </div>
             )}
           </div>

           <div>
             <div className="text-[10px] uppercase tracking-[0.2em] text-text-dim border-b border-border-dark pb-2 mb-4 mt-6">Output Format</div>
             <div className="grid grid-cols-2 gap-3">
                {['image/jpeg', 'image/png', 'image/webp', 'application/pdf'].map(fmt => (
                  <label key={fmt} className="flex items-center gap-2 text-[10px] uppercase tracking-wider text-text-main cursor-pointer group bg-bg-base/50 p-2 border border-border-light hover:border-accent transition-colors transition-all duration-300">
                    <div className={`w-3 h-3 rounded-full border flex items-center justify-center transition-colors ${format === fmt ? 'border-accent' : 'border-border-light group-hover:border-accent'}`}>
                       {format === fmt && <div className="w-1.5 h-1.5 bg-accent rounded-full" />}
                    </div>
                    <input 
                      type="radio" 
                      name="format"
                      checked={format === fmt}
                      onChange={() => setSettings({ ...settings, format: fmt as any })}
                      className="hidden"
                    />
                    {fmt.split('/')[1] === 'pdf' ? 'PDF' : fmt.split('/')[1]}
                  </label>
                ))}
             </div>
           </div>

           <div className="pt-6 flex flex-col gap-3">
             <button onClick={handleDownload} className="btn-primary w-full">
               Execute Download
             </button>
             <button onClick={() => { setFile(null); setPreviewSrc(''); setActivePreset(null); resetHistory(DEFAULT_SETTINGS); }} className="btn-secondary w-full">
               [ Reset Session ]
             </button>
           </div>
        </div>
      </div>
    </div>
  );
}
