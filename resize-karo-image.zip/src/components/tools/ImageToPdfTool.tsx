import React, { useState, useRef } from 'react';
import { Upload, FileDown, Trash2, GripVertical, Scissors, Image as ImageIcon, PenTool } from 'lucide-react';
import jsPDF from 'jspdf';

export function ImageToPdfTool() {
  const [images, setImages] = useState<{ url: string; file: File }[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const filesArray = Array.from(e.target.files) as File[];
      const newImages = filesArray.map(file => ({
        url: URL.createObjectURL(file),
        file
      }));
      setImages(prev => [...prev, ...newImages]);
    }
  };

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
    // Memory management
    URL.revokeObjectURL(images[index].url);
  };

  const generatePDF = async () => {
    if (images.length === 0) return;
    setIsGenerating(true);

    try {
      const pdf = new jsPDF();
      
      for (let i = 0; i < images.length; i++) {
        if (i > 0) pdf.addPage();
        
        const img = new Image();
        img.src = images[i].url;
        await new Promise((resolve) => {
          img.onload = resolve;
        });

        // Calculate fit to A4 (210x297 mm)
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdf.internal.pageSize.getHeight();
        const imgRatio = img.width / img.height;
        const pdfRatio = pdfWidth / pdfHeight;

        let outputWidth = pdfWidth;
        let outputHeight = pdfHeight;

        if (imgRatio > pdfRatio) {
          outputHeight = pdfWidth / imgRatio;
        } else {
          outputWidth = pdfHeight * imgRatio;
        }

        const x = (pdfWidth - outputWidth) / 2;
        const y = (pdfHeight - outputHeight) / 2;

        pdf.addImage(img, 'JPEG', x, y, outputWidth, outputHeight);
      }

      pdf.save('merged_document.pdf');
    } catch (error) {
      console.error("Error generating PDF:", error);
      alert("Failed to generate PDF.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="flex flex-col h-full items-center max-w-5xl mx-auto w-full">
      <div className="text-center mb-12">
        <h2 className="hero-heading">Document<br/>Exporter<span className="serif-italic">&copy;</span></h2>
        <p className="text-text-muted mt-4 max-w-lg mx-auto text-sm">Assemble visual assets into high-performance PDF containers with optimized vector mapping.</p>
      </div>

      <div className="w-full">
        {images.length === 0 ? (
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="w-full glass-panel active:scale-[0.99] p-16 flex flex-col items-center justify-center cursor-pointer hover:border-accent hover:bg-accent/5 transition-all duration-500 group relative overflow-hidden"
          >
            <div className="flex gap-4 mb-8">
              {[Scissors, ImageIcon, PenTool].map((Icon, idx) => (
                <div key={idx} className="w-16 h-16 glass-panel-inner flex items-center justify-center text-accent group-hover:scale-110 transition-all duration-500 bg-white/5 border-white/10">
                  <Icon size={24} />
                </div>
              ))}
            </div>
            <h3 className="text-xl font-bold text-white mb-2 uppercase tracking-widest text-center">Upload Here</h3>
            <p className="text-text-dim text-xs font-mono uppercase tracking-[0.2em] text-center">Multi-Selection Stream: JPG / PNG</p>
          </div>
        ) : (
          <div className="glass-panel p-8">
            <div className="flex items-center justify-between mb-8 pb-4 border-b border-white/10">
              <div>
                <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-text-dim mb-1">Queue Status</div>
                <h3 className="text-lg font-semibold text-white tracking-tight">{images.length} Objects Mapped</h3>
              </div>
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="btn-outline px-6 py-2"
              >
                Insert Layer
              </button>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6 mb-10">
              {images.map((img, idx) => (
                <div key={idx} className="relative group aspect-[3/4] rounded-xl overflow-hidden border border-white/10 bg-black/20 shadow-lg">
                  <img src={img.url} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={`Page ${idx + 1}`} />
                  <div className="absolute inset-0 bg-accent/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
                  <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-[-4px] group-hover:translate-y-0">
                    <button 
                      onClick={() => removeImage(idx)}
                      className="bg-black/80 hover:bg-red-500/80 text-white p-2 rounded-lg backdrop-blur-md border border-white/10 transition-colors"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 bg-black/60 backdrop-blur-sm text-[10px] font-mono text-center py-1.5 text-white/50 group-hover:text-accent transition-colors">
                    SLOT {idx + 1}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex gap-4">
              <button
                onClick={generatePDF}
                disabled={isGenerating}
                className="btn-primary flex-[2]"
              >
                {isGenerating ? 'Compiling Node Structure...' : 'Generate PDF Manifest'}
              </button>
              <button
                onClick={() => setImages([])}
                className="btn-secondary flex-1"
              >
                Reset Queue
              </button>
            </div>
          </div>
        )}
        
        <input 
          type="file" 
          multiple 
          accept="image/*" 
          className="hidden" 
          ref={fileInputRef}
          onChange={handleFileChange}
        />
      </div>
    </div>
  );
}
