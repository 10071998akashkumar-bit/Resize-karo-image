import { Hammer, ArrowLeft } from 'lucide-react';
import type { ToolType } from '../../App';

export function ComingSoonTool({ toolId, onBack }: { toolId: ToolType, onBack: () => void }) {
  
  const getTitle = () => {
    switch (toolId) {
      case 'mergepdf': return 'Merge PDFs';
      case 'compresspdf': return 'Compress PDF';
      case 'crop': return 'Crop Image';
      case 'convert': return 'Convert Image Format';
      case 'pdf2img': return 'PDF to Images';
      case 'removebg': return 'AI Background Removal';
      case 'blur': return 'AI Background Blur';
      case 'quality': return 'Increase Image Quality (AI)';
      default: return 'Feature in Development';
    }
  }

  return (
    <div className="h-full flex flex-col items-center justify-center text-center p-12 glass-panel max-w-2xl mx-auto my-12">
      <div className="w-24 h-24 glass-panel-inner flex items-center justify-center text-accent mb-10 shadow-[0_0_30px_rgba(59,130,246,0.3)]">
        <Hammer size={40} />
      </div>
      
      <div className="text-[10px] font-bold uppercase tracking-[0.3em] mb-4 text-accent/80">Component Pipeline: Locked</div>
      <h2 className="hero-heading uppercase mb-6">
        {getTitle()}
      </h2>
      
      <p className="text-text-muted max-w-sm mb-12 text-sm leading-relaxed opacity-80 font-medium">
        This high-latency module is currently undergoing architectural mapping for local execution.
      </p>
      
      <button 
        onClick={onBack}
        className="btn-primary flex items-center gap-2 px-10"
      >
        <ArrowLeft size={16} />
        Return to Source
      </button>
    </div>
  );
}
