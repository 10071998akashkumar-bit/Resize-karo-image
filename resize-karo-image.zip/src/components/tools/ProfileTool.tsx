import React, { useState, useEffect } from 'react';
import { User, Save, Trash2, ShieldCheck, Clock, Settings, MessageSquare, AlertCircle, Sparkles, LogOut, Trash } from 'lucide-react';

interface UserProfile {
  name: string;
  email: string;
  company: string;
  defaultFormat: 'png' | 'jpg';
  autoDownload: boolean;
}

export function ProfileTool() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [passcode, setPasscode] = useState('');
  const [loginError, setLoginError] = useState(false);
  const [profile, setProfile] = useState<UserProfile>({
    name: '',
    email: '',
    company: '',
    defaultFormat: 'png',
    autoDownload: false,
  });
  const [isSaved, setIsSaved] = useState(false);
  const [feedbackLogs, setFeedbackLogs] = useState<any[]>([]);

  useEffect(() => {
    const savedProfile = localStorage.getItem('user_profile');
    if (savedProfile) {
      setProfile(JSON.parse(savedProfile));
    }

    const logs = JSON.parse(localStorage.getItem('rk_feedback_logs') || '[]');
    setFeedbackLogs(logs);
    
    // Check if admin session exists in sessionStorage (clears on tab close)
    const adminSession = sessionStorage.getItem('admin_authenticated');
    if (adminSession === 'true') {
      setIsAdmin(true);
    }
  }, []);

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Updated administrative passcode for local access control
    if (passcode === 'Resize@karo') {
      setIsAdmin(true);
      sessionStorage.setItem('admin_authenticated', 'true');
      setLoginError(false);
    } else {
      setLoginError(true);
      setTimeout(() => setLoginError(false), 2000);
    }
  };

  const handleLogout = () => {
    setIsAdmin(false);
    sessionStorage.removeItem('admin_authenticated');
  };

  const handleSave = () => {
    localStorage.setItem('user_profile', JSON.stringify(profile));
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const handleClear = () => {
    if (window.confirm('Are you sure you want to clear your local profile data?')) {
      localStorage.removeItem('user_profile');
      setProfile({
        name: '',
        email: '',
        company: '',
        defaultFormat: 'png',
        autoDownload: false,
      });
    }
  };

  const clearFeedback = () => {
    if (window.confirm('Clear all feedback logs?')) {
      localStorage.removeItem('rk_feedback_logs');
      setFeedbackLogs([]);
    }
  };

  if (!isAdmin) {
    return (
      <div className="w-full max-w-md mx-auto py-20">
        <div className="glass-panel p-10 flex flex-col items-center">
          <div className="w-16 h-16 bg-accent/20 rounded-2xl flex items-center justify-center text-accent mb-8 shadow-[0_0_20px_rgba(59,130,246,0.3)]">
            <ShieldCheck size={32} />
          </div>
          <h2 className="text-2xl font-heading font-black text-white uppercase tracking-tighter mb-2">
            Admin Access Required
          </h2>
          <p className="text-[10px] text-text-muted font-mono uppercase tracking-[0.2em] mb-8">
            Secure Node Authentication
          </p>
          
          <form onSubmit={handleAdminLogin} className="w-full space-y-4">
            <div className="space-y-3 w-full group/input">
              <label className="text-[10px] font-bold text-text-dim uppercase tracking-[0.3em] block px-1 group-focus-within/input:text-accent transition-colors">
                Administrative Passcode
              </label>
              <div className="relative">
                <input 
                  type="password" 
                  value={passcode}
                  onChange={(e) => setPasscode(e.target.value)}
                  className={`w-full bg-black/40 border-2 rounded-xl px-4 py-4 text-center tracking-[1.2em] font-black text-white focus:outline-none transition-all duration-500 shadow-[inset_0_2px_10px_rgba(0,0,0,0.5)] ${
                    loginError 
                      ? 'border-rose-500/50 shadow-[0_0_20px_rgba(244,63,94,0.2)] animate-shake' 
                      : 'border-white/5 focus:border-accent shadow-[0_0_0_rgba(59,130,246,0)] focus:shadow-[0_0_30px_rgba(59,130,246,0.15)]'
                  }`}
                  placeholder="••••••••"
                  autoFocus
                />
                {/* Decorative corner accents for the input */}
                <div className="absolute top-0 left-0 w-2 h-2 border-t-2 border-l-2 border-white/10 rounded-tl-lg group-focus-within/input:border-accent transition-colors" />
                <div className="absolute top-0 right-0 w-2 h-2 border-t-2 border-r-2 border-white/10 rounded-tr-lg group-focus-within/input:border-accent transition-colors" />
                <div className="absolute bottom-0 left-0 w-2 h-2 border-b-2 border-l-2 border-white/10 rounded-bl-lg group-focus-within/input:border-accent transition-colors" />
                <div className="absolute bottom-0 right-0 w-2 h-2 border-b-2 border-r-2 border-white/10 rounded-br-lg group-focus-within/input:border-accent transition-colors" />
              </div>
            </div>
            <button 
              type="submit"
              className="btn-primary w-full bg-accent hover:bg-accent/90"
            >
              INITIALIZE SESSION
            </button>
            {loginError && (
              <p className="text-[10px] text-rose-400 font-bold uppercase tracking-widest text-center mt-2">
                Authentication Failure
              </p>
            )}
          </form>
          
          <div className="mt-10 pt-6 border-t border-white/5 w-full text-center">
             <p className="text-[9px] text-text-dim italic leading-tight">
               Access restricted to authorized personnel only. All session activities are logged locally within the browser context.
             </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-4xl mx-auto py-4">
      <div className="flex flex-col md:flex-row items-baseline justify-between gap-4 mb-4">
        <div className="flex items-baseline gap-4">
          <h2 className="text-3xl font-heading font-black text-white uppercase tracking-tighter">
            Admin Settings
          </h2>
          <span className="text-[10px] font-mono text-accent tracking-[0.2em] font-bold uppercase">
            Privileged session
          </span>
        </div>
        <button 
          onClick={handleLogout}
          className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-[10px] font-bold text-text-dim hover:text-rose-400 uppercase tracking-widest transition-all flex items-center gap-2"
        >
          <LogOut size={14} />
          Terminate Session
        </button>
      </div>

      <div className="space-y-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Profile Form */}
        <div className="lg:col-span-2 space-y-6">
          <div className="glass-panel p-8">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 bg-accent/20 rounded-lg flex items-center justify-center text-accent">
                <User size={20} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white uppercase tracking-wider">Identity Node</h3>
                <p className="text-[10px] text-text-muted font-mono uppercase tracking-widest">Personal Identification Data</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-text-dim uppercase tracking-widest px-1">Full Name</label>
                <input 
                  type="text" 
                  value={profile.name}
                  onChange={(e) => setProfile({...profile, name: e.target.value})}
                  className="input-base w-full"
                  placeholder="e.g. Alex Henderson"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-text-dim uppercase tracking-widest px-1">Email Address</label>
                <input 
                  type="email" 
                  value={profile.email}
                  onChange={(e) => setProfile({...profile, email: e.target.value})}
                  className="input-base w-full"
                  placeholder="alex@studio.node"
                />
              </div>
              <div className="space-y-2 md:col-span-2">
                <label className="text-[10px] font-bold text-text-dim uppercase tracking-widest px-1">Organization / Company</label>
                <input 
                  type="text" 
                  value={profile.company}
                  onChange={(e) => setProfile({...profile, company: e.target.value})}
                  className="input-base w-full"
                  placeholder="Digital Core Systems"
                />
              </div>
            </div>
          </div>

          <div className="glass-panel p-8">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 bg-emerald-400/20 rounded-lg flex items-center justify-center text-emerald-400">
                <Settings size={20} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white uppercase tracking-wider">Workflow Configuration</h3>
                <p className="text-[10px] text-text-muted font-mono uppercase tracking-widest">Automation & Format Presets</p>
              </div>
            </div>

            <div className="space-y-6">
              <div className="flex items-center justify-between p-4 glass-panel-inner">
                <div>
                  <p className="text-sm font-bold text-white uppercase tracking-tight">Default Export Format</p>
                  <p className="text-[10px] text-text-muted italic">Preferred rasterization target for all image tools</p>
                </div>
                <div className="flex bg-white/5 p-1 rounded-lg border border-white/10">
                  <button 
                    onClick={() => setProfile({...profile, defaultFormat: 'png'})}
                    className={`px-4 py-1.5 text-[10px] font-bold rounded-md transition-all ${profile.defaultFormat === 'png' ? 'bg-accent text-white shadow-lg' : 'text-text-muted hover:text-white'}`}
                  >
                    PNG
                  </button>
                  <button 
                    onClick={() => setProfile({...profile, defaultFormat: 'jpg'})}
                    className={`px-4 py-1.5 text-[10px] font-bold rounded-md transition-all ${profile.defaultFormat === 'jpg' ? 'bg-accent text-white shadow-lg' : 'text-text-muted hover:text-white'}`}
                  >
                    JPG
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 glass-panel-inner">
                <div>
                  <p className="text-sm font-bold text-white uppercase tracking-tight">Immediate Post-Process Download</p>
                  <p className="text-[10px] text-text-muted italic">Automatically trigger file stream after calculation</p>
                </div>
                <button 
                  onClick={() => setProfile({...profile, autoDownload: !profile.autoDownload})}
                  className={`w-12 h-6 rounded-full transition-all relative ${profile.autoDownload ? 'bg-accent' : 'bg-white/10'}`}
                >
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${profile.autoDownload ? 'left-7' : 'left-1'}`} />
                </button>
              </div>
            </div>
          </div>

          <div className="flex gap-4">
            <button 
              onClick={handleSave}
              className="btn-primary flex-1 bg-accent hover:bg-accent/90"
            >
              <Save size={18} />
              {isSaved ? 'CONFIGURATION LOCKED' : 'COMMIT SETTINGS'}
            </button>
            <button 
              onClick={handleClear}
              className="btn-secondary px-8 border-rose-500/30 hover:bg-rose-500/10 hover:text-rose-400 group"
            >
              <Trash2 size={18} className="group-hover:rotate-12 transition-transform" />
            </button>
          </div>
        </div>

        {/* Sidebar Info */}
        <div className="space-y-6">
          <div className="glass-panel p-8 border-emerald-500/20">
            <div className="w-12 h-12 bg-emerald-400/10 rounded-xl flex items-center justify-center text-emerald-400 mb-6">
              <ShieldCheck size={24} />
            </div>
            <h4 className="text-sm font-bold text-white uppercase tracking-widest mb-4">Privacy Protocol</h4>
            <p className="text-[11px] text-text-muted leading-relaxed italic opacity-80">
              No data is transmitted to external servers. Your profile information is stored exclusively in your browser's persistent storage (LocalStorage). This ensures absolute confidentiality of your identity data.
            </p>
          </div>

          <div className="glass-panel p-8 border-blue-500/20">
            <div className="w-12 h-12 bg-blue-400/10 rounded-xl flex items-center justify-center text-blue-400 mb-6">
              <Clock size={24} />
            </div>
            <h4 className="text-sm font-bold text-white uppercase tracking-widest mb-4">Time Efficiency</h4>
            <p className="text-[11px] text-text-muted leading-relaxed italic opacity-80">
              By defining your identity defaults, you reduce operational redundancy during export sequences. All document headers and signatures will auto-populate using these localized parameters.
            </p>
          </div>
        </div>
      </div>

      {/* Admin Intelligence: Feedback Logs */}
      <div className="mt-16 pb-20">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-accent/20 rounded-2xl flex items-center justify-center text-accent">
              <MessageSquare size={24} />
            </div>
            <div>
              <h3 className="text-2xl font-heading font-black text-white uppercase tracking-tighter">Insights Feed</h3>
              <p className="text-[10px] text-text-muted font-mono uppercase tracking-[0.2em]">Community intelligence logs</p>
            </div>
          </div>
          {feedbackLogs.length > 0 && (
            <button 
              onClick={clearFeedback}
              className="btn-secondary h-9 px-4 border-rose-500/20 text-rose-400 hover:bg-rose-500/10"
            >
              <Trash size={14} />
              <span className="text-[10px] font-bold uppercase tracking-widest">Wipe Logs</span>
            </button>
          )}
        </div>

        {feedbackLogs.length === 0 ? (
          <div className="glass-panel p-16 text-center">
            <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center text-text-dim mx-auto mb-6">
              <Clock size={32} />
            </div>
            <p className="text-text-muted italic text-sm">No incoming transmissions recorded in this local enclave.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {feedbackLogs.map((log) => (
              <div key={log.id} className="glass-panel p-6 relative group border-white/5 hover:border-white/10 transition-colors">
                <div className="flex justify-between items-start mb-4">
                  <div className={`px-2 py-1 rounded text-[8px] font-black uppercase tracking-widest ${
                    log.type === 'suggestion' ? 'bg-accent/20 text-accent' : 
                    log.type === 'issue' ? 'bg-rose-500/20 text-rose-500' : 'bg-white/10 text-white'
                  }`}>
                    {log.type}
                  </div>
                  <span className="text-[9px] font-mono text-text-dim">
                    {new Date(log.timestamp).toLocaleString()}
                  </span>
                </div>
                <p className="text-sm text-text-main italic leading-relaxed mb-4">
                  "{log.message}"
                </p>
                <div className="absolute bottom-4 right-6 opacity-0 group-hover:opacity-20 transition-opacity">
                  {log.type === 'suggestion' ? <Sparkles size={16} /> : log.type === 'issue' ? <AlertCircle size={16} /> : <MessageSquare size={16} />}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  </div>
);
}
