import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, Download, RefreshCw, Layers, Palette, ImageIcon, Info } from 'lucide-react';

declare global {
  interface Window {
    imglyRemoveBackground?: (image: string | File | URL) => Promise<Blob>;
  }
}

export function RemoveBgTool() {
  const [image, setImage] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [bgColor, setBgColor] = useState('#ffffff');
  const [useColor, setUseColor] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    // Load the imgly library script if not already present
    if (!document.getElementById('imgly-sdk')) {
      const script = document.createElement('script');
      script.id = 'imgly-sdk';
      script.src = 'https://cdn.jsdelivr.net/npm/@imgly/background-removal@1.5.5/dist/index.js';
      script.async = true;
      document.body.appendChild(script);
    }
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setImage(reader.result as string);
        setResult(null);
        setError(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const processImage = async () => {
    if (!image) return;
    if (!window.imglyRemoveBackground) {
      setError("AI Engine is still initializing. Please wait a moment.");
      return;
    }

    setIsProcessing(true);
    setError(null);

    try {
      const blob = await window.imglyRemoveBackground(image);
      const url = URL.createObjectURL(blob);
      setResult(url);
    } catch (err) {
      console.error(err);
      setError("Failed to process background removal. Is the subject clearly defined?");
    } finally {
      setIsProcessing(false);
    }
  };

  const downloadResult = () => {
    if (!result) return;
    
    if (useColor && canvasRef.current) {
      const canvas = canvasRef.current;
      const link = document.createElement('a');
      link.download = 'removed_bg_with_color.jpg';
      link.href = canvas.toDataURL('image/jpeg', 0.9);
      link.click();
    } else {
      const link = document.createElement('a');
      link.download = 'removed_bg.png';
      link.href = result;
      link.click();
    }
  };

  const applyColorOnCanvas = () => {
    if (!result || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      if (useColor) {
        ctx.fillStyle = bgColor;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }
      ctx.drawImage(img, 0, 0);
    };
    img.src = result;
  };

  useEffect(() => {
    if (result) applyColorOnCanvas();
  }, [result, bgColor, useColor]);

  return (
    <div className="flex flex-col h-full items-center max-w-5xl mx-auto w-full">
      <div className="text-center mb-12">
        <h2 className="hero-heading uppercase tracking-tight">Background<br/>Removal<span className="serif-italic">&copy;</span></h2>
        <p className="text-text-muted mt-4 max-w-lg mx-auto text-sm leading-relaxed opacity-80">
          State-of-the-art background removal using WASM-accelerated computer vision. Edge detection calibrated for precision.
        </p>
      </div>

      {!image ? (
        <div 
          onClick={() => fileInputRef.current?.click()}
          className="w-full glass-panel p-20 flex flex-col items-center justify-center cursor-pointer hover:border-accent hover:bg-accent/5 transition-all duration-500 group relative overflow-hidden"
        >
          <div className="w-20 h-20 glass-panel-inner flex items-center justify-center text-accent mb-8 group-hover:scale-110 transition-all duration-500 ring-8 ring-accent/5">
            <Sparkles size={32} />
          </div>
          <h3 className="text-xl font-bold text-white mb-2 uppercase tracking-[0.2em]">Upload Here</h3>
          <p className="text-text-dim text-[10px] font-mono tracking-widest uppercase">Subjects: People / Products / Icons</p>
        </div>
      ) : (
        <div className="flex flex-col lg:flex-row gap-8 w-full">
          <div className="flex-1 space-y-6">
            <div className="glass-panel p-6 min-h-[400px] flex items-center justify-center bg-black/40 relative overflow-hidden group">
               {!result ? (
                 <img src={image} className="max-w-full max-h-[500px] object-contain rounded-lg shadow-2xl transition-all duration-500" alt="Source" />
               ) : (
                 <div className="relative">
                   <canvas ref={canvasRef} className="max-w-full max-h-[500px] object-contain rounded-lg shadow-2xl" />
                   {useColor && (
                     <div className="absolute top-4 left-4 glass-panel-inner px-3 py-1 text-[8px] font-bold text-white uppercase tracking-widest bg-accent/20 border-accent/20">
                       Color Composite Active
                     </div>
                   )}
                 </div>
               )}
               
               {isProcessing && (
                 <div className="absolute inset-0 bg-bg-base/80 backdrop-blur-sm flex flex-col items-center justify-center z-20">
                    <div className="w-16 h-16 bg-accent/20 rounded-2xl flex items-center justify-center text-accent border border-accent/20 mb-6 animate-pulse">
                       <RefreshCw size={28} className="animate-spin" />
                    </div>
                    <div className="text-[10px] font-bold text-white uppercase tracking-[0.3em] mb-2">Analyzing Tensors...</div>
                    <div className="text-text-dim text-[8px] uppercase tracking-widest leading-relaxed text-center px-12">This operation occurs locally on your GPU. Please do not close this window.</div>
                 </div>
               )}
            </div>
            
            {error && (
              <div className="p-4 bg-red-500/10 border border-red-500/20 text-red-500 text-[10px] font-bold uppercase tracking-widest rounded-xl text-center">
                {error}
              </div>
            )}

            {!result && !isProcessing && (
              <button 
                onClick={processImage}
                className="btn-primary w-full py-6 flex items-center justify-center gap-3 text-lg"
              >
                <Sparkles size={24} />
                Execute Extraction
              </button>
            )}
          </div>

          <div className="w-full lg:w-[320px] shrink-0 space-y-6">
            <div className="glass-panel p-6 space-y-8">
              <div>
                <div className="text-[10px] uppercase tracking-[0.2em] text-text-dim border-b border-border-dark pb-3 mb-6 flex items-center gap-2">
                  <Palette size={14} className="text-accent" />
                  Visual Compositing
                </div>
                
                <div className="space-y-6">
                   <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-text-muted uppercase tracking-widest">Composite Mode</span>
                      <button 
                        onClick={() => setUseColor(!useColor)}
                        className={`w-12 h-6 rounded-full p-1 transition-all duration-500 relative ${useColor ? 'bg-accent shadow-[0_0_15px_rgba(59,130,246,0.5)]' : 'bg-white/10 border border-white/5'}`}
                      >
                         <div className={`w-4 h-4 rounded-full bg-white transition-all duration-500 ${useColor ? 'ml-6' : 'ml-0'}`} />
                      </button>
                   </div>
                   
                   <div className={`transition-all duration-500 ${useColor ? 'opacity-100' : 'opacity-30 pointer-events-none grayscale'}`}>
                      <label className="text-[10px] font-bold text-text-dim uppercase tracking-widest mb-3 block">Fill Color</label>
                      <div className="flex gap-3">
                         <input 
                           type="color" 
                           value={bgColor} 
                           onChange={(e) => setBgColor(e.target.value)}
                           className="w-12 h-12 bg-transparent cursor-pointer rounded-lg overflow-hidden border-0"
                         />
                         <div className="flex-1 glass-panel-inner p-3 flex items-center font-mono text-xs uppercase tracking-widest">
                           {bgColor}
                         </div>
                      </div>
                   </div>
                </div>
              </div>

              <div className="pt-6 space-y-4">
                 <button 
                   onClick={downloadResult}
                   disabled={!result}
                   className="btn-primary w-full disabled:opacity-20 flex items-center justify-center gap-3"
                 >
                   <Download size={18} />
                   Save Result
                 </button>
                 <button 
                   onClick={() => { setImage(null); setResult(null); setUseColor(false); }}
                   className="btn-secondary w-full"
                 >
                   Discard Work
                 </button>
              </div>

              <div className="p-4 bg-accent/5 border border-accent/20 rounded-2xl">
                 <div className="flex gap-3 text-accent mb-3">
                    <Info size={16} />
                    <span className="text-[10px] font-bold uppercase tracking-widest">Local Engine</span>
                 </div>
                 <p className="text-[9px] text-text-muted leading-relaxed uppercase tracking-tighter opacity-70">
                   Background removal is computed entirely within your secure browser sandbox using WASM. Your private images are never offloaded to any cloud servers.
                 </p>
              </div>
            </div>
          </div>
        </div>
      )}

      <input 
        type="file" 
        accept="image/*" 
        className="hidden" 
        ref={fileInputRef}
        onChange={handleFileChange}
      />
    </div>
  );
}
