import React, { useState } from 'react';
import { MessageSquare, Send, Sparkles, AlertCircle, Heart } from 'lucide-react';

type FeedbackType = 'suggestion' | 'issue' | 'other';

export function FeedbackTool() {
  const [type, setType] = useState<FeedbackType>('suggestion');
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    const feedbackEntry = {
      id: Date.now().toString(),
      type,
      message,
      timestamp: new Date().toISOString(),
    };

    // Save to localStorage for Admin Hub retrieval
    const existingFeedback = JSON.parse(localStorage.getItem('rk_feedback_logs') || '[]');
    localStorage.setItem('rk_feedback_logs', JSON.stringify([feedbackEntry, ...existingFeedback]));
    
    setIsSubmitted(true);
    setMessage('');
  };

  if (isSubmitted) {
    return (
      <div className="w-full max-w-2xl mx-auto py-12 text-center">
        <div className="glass-panel p-12 flex flex-col items-center">
          <div className="w-20 h-20 bg-emerald-400/20 rounded-full flex items-center justify-center text-emerald-400 mb-6 animate-bounce">
            <Heart size={40} fill="currentColor" fillOpacity={0.2} />
          </div>
          <h2 className="text-3xl font-heading font-black text-white uppercase tracking-tighter mb-4">
            Transmission Received
          </h2>
          <p className="text-text-muted text-sm italic mb-8 max-w-md">
            Your insights have been logged into our development queue. We prioritize community-driven architectural enhancements.
          </p>
          <button 
            onClick={() => setIsSubmitted(false)}
            className="btn-primary"
          >
            Send Another Insight
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-4xl mx-auto py-4">
      <div className="flex flex-col md:flex-row items-baseline gap-4 mb-4">
        <h2 className="text-3xl font-heading font-black text-white uppercase tracking-tighter">
          Feedback Hub
        </h2>
        <span className="text-[10px] font-mono text-accent tracking-[0.2em] font-bold uppercase">
          Neural Improvement Loop
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit} className="glass-panel p-8 space-y-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-accent/20 rounded-lg flex items-center justify-center text-accent">
                <MessageSquare size={20} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white uppercase tracking-wider">Submit Insight</h3>
                <p className="text-[10px] text-text-muted font-mono uppercase tracking-widest">Constructive architectural evaluation</p>
              </div>
            </div>

            <div className="space-y-4">
              <label className="text-[10px] font-bold text-text-dim uppercase tracking-widest block px-1">Evaluation Category</label>
              <div className="grid grid-cols-3 gap-4">
                <button
                  type="button"
                  onClick={() => setType('suggestion')}
                  className={`flex flex-col items-center gap-3 p-4 rounded-xl border transition-all ${
                    type === 'suggestion' 
                    ? 'bg-accent/10 border-accent text-accent shadow-[0_0_15px_rgba(59,130,246,0.2)]' 
                    : 'bg-white/5 border-white/10 text-text-muted hover:border-white/20'
                  }`}
                >
                  <Sparkles size={20} />
                  <span className="text-[10px] font-bold tracking-widest uppercase">Feature</span>
                </button>
                <button
                  type="button"
                  onClick={() => setType('issue')}
                  className={`flex flex-col items-center gap-3 p-4 rounded-xl border transition-all ${
                    type === 'issue' 
                    ? 'bg-rose-500/10 border-rose-500 text-rose-500 shadow-[0_0_15px_rgba(244,63,94,0.2)]' 
                    : 'bg-white/5 border-white/10 text-text-muted hover:border-white/20'
                  }`}
                >
                  <AlertCircle size={20} />
                  <span className="text-[10px] font-bold tracking-widest uppercase">Bug</span>
                </button>
                <button
                  type="button"
                  onClick={() => setType('other')}
                  className={`flex flex-col items-center gap-3 p-4 rounded-xl border transition-all ${
                    type === 'other' 
                    ? 'bg-white/10 border-white/40 text-white shadow-[0_0_15px_rgba(255,255,255,0.1)]' 
                    : 'bg-white/5 border-white/10 text-text-muted hover:border-white/20'
                  }`}
                >
                  <MessageSquare size={20} />
                  <span className="text-[10px] font-bold tracking-widest uppercase">Other</span>
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-bold text-text-dim uppercase tracking-widest block px-1">Describe your suggestion</label>
              <textarea 
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                required
                rows={6}
                className="input-base w-full resize-none custom-scrollbar"
                placeholder="How can we further optimize the Resize Karo experience?"
              />
            </div>

            <button 
              type="submit"
              disabled={!message.trim()}
              className="btn-primary w-full group disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send size={18} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
              TRANSMIT FEEDBACK
            </button>
          </form>
        </div>

        <div className="space-y-6">
          <div className="glass-panel p-8 border-accent/20">
            <h4 className="text-sm font-bold text-white uppercase tracking-widest mb-4">Community Driven</h4>
            <p className="text-[11px] text-text-muted leading-relaxed italic opacity-80 mb-6">
              Resize Karo is built on user insights. Every tool currently in production was once a fragment of user feedback.
            </p>
            <div className="space-y-4">
               {[
                 { label: 'Feature Votes', value: '412' },
                 { label: 'Solved Issues', value: '89' },
                 { label: 'Studio Version', value: '2.4.0' }
               ].map((stat, i) => (
                 <div key={i} className="flex justify-between items-center py-2 border-b border-white/5">
                   <span className="text-[10px] font-mono text-text-dim uppercase tracking-widest">{stat.label}</span>
                   <span className="text-xs font-bold text-accent">{stat.value}</span>
                 </div>
               ))}
            </div>
          </div>
          
          <div className="glass-panel p-8">
            <h4 className="text-sm font-bold text-white uppercase tracking-widest mb-4">Direct Communication</h4>
            <p className="text-[11px] text-text-muted leading-relaxed italic opacity-80">
              Need a custom integration or have complex requirements? Reach out to our architectural team directly at <span className="text-accent underline cursor-pointer">dev@resizekaro.studio</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
