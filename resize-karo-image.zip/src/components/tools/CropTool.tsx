import React, { useState, useCallback, useRef } from 'react';
import Cropper, { Area, Point } from 'react-easy-crop';
import { Scissors, Download, RefreshCw, Maximize2, Crop as CropIcon, Image as ImageIcon, Undo2, Redo2, RotateCw, RotateCcw } from 'lucide-react';
import { useHistory } from '../../hooks/useHistory';

interface CropSettings {
  crop: Point;
  zoom: number;
  rotation: number;
  aspect: number | undefined;
  customRatio: { w: string, h: string };
}

const DEFAULT_SETTINGS: CropSettings = {
  crop: { x: 0, y: 0 },
  zoom: 1,
  rotation: 0,
  aspect: undefined,
  customRatio: { w: '', h: '' }
};

export function CropTool() {
  const [image, setImage] = useState<string | null>(null);
  const [croppedAreaPixels, setCroppedAreaPixels] = useState<Area | null>(null);
  
  const { state: settings, setState: setSettings, undo, redo, canUndo, canRedo } = useHistory<CropSettings>(DEFAULT_SETTINGS);
  const { crop, zoom, rotation, aspect, customRatio } = settings;
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleCustomRatioChange = (type: 'w' | 'h', val: string) => {
    const nextRatio = { ...customRatio, [type]: val };
    const w = parseFloat(nextRatio.w);
    const h = parseFloat(nextRatio.h);
    
    setSettings({
      ...settings,
      customRatio: nextRatio,
      aspect: (w > 0 && h > 0) ? w / h : undefined
    });
  };

  const handlePresetChange = (val: number | undefined) => {
    setSettings({
      ...settings,
      aspect: val,
      customRatio: { w: '', h: '' }
    });
  };

  const onCropComplete = useCallback((_croppedArea: Area, croppedAreaPixels: Area) => {
    setCroppedAreaPixels(croppedAreaPixels);
    // Commit the final crop position to history
    setSettings(prev => ({ ...prev }), false); 
  }, [setSettings]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.addEventListener('load', () => setImage(reader.result as string));
      reader.readAsDataURL(file);
    }
  };

  const createImage = (url: string): Promise<HTMLImageElement> =>
    new Promise((resolve, reject) => {
      const image = new Image();
      image.addEventListener('load', () => resolve(image));
      image.addEventListener('error', (error) => reject(error));
      image.setAttribute('crossOrigin', 'anonymous');
      image.src = url;
    });

  const getCroppedImg = async (
    imageSrc: string,
    pixelCrop: Area,
    rotation = 0
  ): Promise<string | null> => {
    const image = await createImage(imageSrc);
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    if (!ctx) return null;

    const rotRad = (rotation * Math.PI) / 180;
    const { width: bBoxW, height: bBoxH } = rotateSize(image.width, image.height, rotation);

    // Set canvas size to the bounding box of rotated image
    canvas.width = bBoxW;
    canvas.height = bBoxH;

    // Translate to center and rotate
    ctx.translate(bBoxW / 2, bBoxH / 2);
    ctx.rotate(rotRad);
    ctx.translate(-image.width / 2, -image.height / 2);

    // Draw rotated image
    ctx.drawImage(image, 0, 0);

    // Now extract the cropped area
    const data = ctx.getImageData(
      pixelCrop.x,
      pixelCrop.y,
      pixelCrop.width,
      pixelCrop.height
    );

    // Resize canvas to final crop size
    canvas.width = pixelCrop.width;
    canvas.height = pixelCrop.height;

    // Put extracted data back
    ctx.putImageData(data, 0, 0);

    return new Promise((resolve) => {
      canvas.toBlob((blob) => {
        if (!blob) return resolve(null);
        resolve(URL.createObjectURL(blob));
      }, 'image/jpeg');
    });
  };

  const rotateSize = (width: number, height: number, rotation: number) => {
    const rotRad = (rotation * Math.PI) / 180;
    return {
      width:
        Math.abs(Math.cos(rotRad) * width) + Math.abs(Math.sin(rotRad) * height),
      height:
        Math.abs(Math.sin(rotRad) * width) + Math.abs(Math.cos(rotRad) * height),
    };
  };

  const showCroppedImage = async () => {
    try {
      if (!image || !croppedAreaPixels) return;
      const croppedImage = await getCroppedImg(image, croppedAreaPixels, rotation);
      if (croppedImage) {
        const link = document.createElement('a');
        link.href = croppedImage;
        link.download = 'cropped-image.jpg';
        link.click();
      }
    } catch (e) {
      console.error(e);
    }
  };

  if (!image) {
    return (
      <div className="flex flex-col h-full items-center max-w-5xl mx-auto w-full">
        <div className="text-center mb-12">
          <h2 className="hero-heading">Crop<br/>Image<span className="serif-italic">&copy;</span></h2>
          <p className="text-text-muted mt-4 max-w-lg mx-auto text-sm">Refine your composition with surgical accuracy. Calibrated for high-fidelity output.</p>
        </div>

        <div 
          onClick={() => fileInputRef.current?.click()}
          className="w-full glass-panel active:scale-[0.99] p-16 flex flex-col items-center justify-center cursor-pointer hover:border-accent hover:bg-accent/5 transition-all duration-500 group relative overflow-hidden"
        >
          <div className="flex gap-4 mb-8">
            <div className="w-16 h-16 glass-panel-inner flex items-center justify-center text-accent group-hover:scale-110 group-hover:rotate-6 transition-all duration-500 bg-white/5 border-white/10">
              <Scissors size={24} />
            </div>
            <div className="w-16 h-16 glass-panel-inner flex items-center justify-center text-accent group-hover:scale-110 group-hover:-rotate-6 transition-all duration-500 bg-white/5 border-white/10">
              <CropIcon size={24} />
            </div>
          </div>
          <h3 className="text-xl font-bold text-white mb-2 uppercase tracking-widest text-center">Upload Here</h3>
          <p className="text-text-dim text-xs font-mono uppercase tracking-[0.2em] text-center">Supported: RAW / JPEG / PNG</p>
        </div>
        
        <input 
          type="file" 
          accept="image/*" 
          className="hidden" 
          ref={fileInputRef}
          onChange={handleFileChange}
        />

        <div className="mt-16 w-full grid grid-cols-2 md:grid-cols-4 gap-4">
           {[
             { label: 'Passport Size', ratio: 3.5/4.5 },
             { label: 'Square', ratio: 1 },
             { label: 'Portrait 4:5', ratio: 0.8 },
             { label: 'A4 Document', ratio: 210/297 },
           ].map((item, idx) => (
             <div key={idx} onClick={() => { handlePresetChange(item.ratio); fileInputRef.current?.click(); }}
                  className="glass-panel-inner p-6 hover:border-accent hover:bg-accent/5 cursor-pointer transition-all duration-300 group flex flex-col items-center text-center">
                <div className="text-accent/30 font-mono text-[10px] mb-2">{idx + 1}</div>
                <div className="font-bold text-[10px] uppercase tracking-widest text-text-muted group-hover:text-white transition-colors">
                  {item.label}
                </div>
             </div>
           ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col lg:flex-row gap-6 h-full max-w-6xl mx-auto w-full">
      <div className="flex-1 flex flex-col">
        <div className="glass-panel p-6 flex flex-col min-h-[500px] relative overflow-hidden bg-black/40">
          {/* Undo/Redo Floating Controls */}
          <div className="absolute top-6 left-6 flex gap-2 z-30">
            <button 
              onClick={undo}
              disabled={!canUndo}
              className="p-2 bg-black/60 backdrop-blur-md rounded-lg border border-white/10 text-white disabled:opacity-20 hover:bg-black/80 transition-all font-bold"
              title="Undo"
            >
              <Undo2 size={16} />
            </button>
            <button 
              onClick={redo}
              disabled={!canRedo}
              className="p-2 bg-black/60 backdrop-blur-md rounded-lg border border-white/10 text-white disabled:opacity-20 hover:bg-black/80 transition-all font-bold"
              title="Redo"
            >
              <Redo2 size={16} />
            </button>
          </div>

          <div className="absolute inset-0">
            <Cropper
              image={image}
              crop={crop}
              zoom={zoom}
              rotation={rotation}
              aspect={aspect}
              onCropChange={(c) => setSettings({ ...settings, crop: c }, true)}
              onRotationChange={(r) => setSettings({ ...settings, rotation: r }, true)}
              onCropComplete={onCropComplete}
              onZoomChange={(z) => setSettings({ ...settings, zoom: z }, true)}
              classes={{
                containerClassName: "bg-surface/50",
                mediaClassName: "opacity-90 shadow-2xl",
                cropAreaClassName: "border-2 border-accent shadow-[0_0_50px_rgba(59,130,246,0.3)] !rounded-none"
              }}
            />
          </div>
          
          {/* Zoom & Rotation Control Overlay */}
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-6 bg-bg-base/80 backdrop-blur-md px-6 py-3 rounded-full border border-white/10 z-20">
             <div className="flex items-center gap-2 border-r border-white/10 pr-4">
                <button 
                  onClick={() => setSettings({ ...settings, rotation: rotation - 90 })} 
                  className="p-1.5 text-white hover:text-accent hover:bg-white/5 rounded-lg transition-all"
                  title="Rotate CCW"
                >
                  <RotateCcw size={16} />
                </button>
                <button 
                  onClick={() => setSettings({ ...settings, rotation: rotation + 90 })} 
                  className="p-1.5 text-white hover:text-accent hover:bg-white/5 rounded-lg transition-all"
                  title="Rotate CW"
                >
                  <RotateCw size={16} />
                </button>
             </div>

             <div className="flex items-center gap-4">
               <button onClick={() => setSettings({ ...settings, zoom: Math.max(1, zoom - 0.2) })} className="text-white hover:text-accent transition-colors"><RefreshCw size={14} /></button>
               <input
                  type="range"
                  value={zoom}
                  min={1}
                  max={3}
                  step={0.1}
                  aria-labelledby="Zoom"
                  onChange={(e) => setSettings({ ...settings, zoom: Number(e.target.value) })}
                  className="w-32 accent-accent cursor-pointer"
                />
                <button onClick={() => setSettings({ ...settings, zoom: Math.min(3, zoom + 0.2) })} className="text-white hover:text-accent transition-colors"><Maximize2 size={14} /></button>
             </div>
          </div>
        </div>
      </div>

      <div className="w-full lg:w-[320px] shrink-0">
        <div className="glass-panel p-6 space-y-6">
          <div>
            <div className="text-[10px] uppercase tracking-[0.2em] text-text-dim border-b border-border-dark pb-2 mb-4">Geometry Presets</div>
            <div className="grid grid-cols-3 gap-2">
              {[
                { label: 'Free', val: undefined },
                { label: '1:1', val: 1 },
                { label: '4:3', val: 4/3 },
                { label: '16:9', val: 16/9 },
                { label: '3:2', val: 3/2 },
                { label: '5:4', val: 5/4 },
              ].map((r) => (
                <button
                  key={r.label}
                  onClick={() => handlePresetChange(r.val)}
                  className={`py-2 text-[9px] font-bold uppercase tracking-widest border transition-all duration-300 ${
                    aspect === r.val 
                      ? 'bg-accent border-accent text-white' 
                      : 'border-border-light text-text-muted hover:border-accent hover:text-white'
                  }`}
                >
                  {r.label}
                </button>
              ))}
            </div>
            
            <div className="mt-4 pt-6 border-t border-white/5 space-y-4">
               <div>
                  <label className="text-[10px] font-bold text-text-dim uppercase tracking-[0.2em] mb-3 block">Custom Aspect Ratio</label>
                  <div className="flex gap-3 items-center">
                    <div className="flex-1">
                      <span className="text-[8px] uppercase text-text-muted block mb-1 font-mono">Width</span>
                      <input 
                        type="number" 
                        placeholder="1"
                        value={customRatio.w}
                        className="w-full bg-black/40 border border-white/10 rounded px-3 py-2 text-xs font-mono text-white focus:border-accent outline-none transition-all"
                        onChange={(e) => handleCustomRatioChange('w', e.target.value)}
                      />
                    </div>
                    <div className="pt-4 text-text-dim font-bold">:</div>
                    <div className="flex-1">
                      <span className="text-[8px] uppercase text-text-muted block mb-1 font-mono">Height</span>
                      <input 
                        type="number" 
                        placeholder="1"
                        value={customRatio.h}
                        className="w-full bg-black/40 border border-white/10 rounded px-3 py-2 text-xs font-mono text-white focus:border-accent outline-none transition-all"
                        onChange={(e) => handleCustomRatioChange('h', e.target.value)}
                      />
                    </div>
                  </div>
                  <p className="text-[9px] text-text-dim mt-2 tracking-wide leading-relaxed">
                    Enter integers (e.g., 21:9) or decimals to compute a custom crop boundary.
                  </p>
               </div>
            </div>
          </div>

          <div className="pt-6 space-y-3">
             <button
               onClick={showCroppedImage}
               className="btn-primary w-full flex items-center justify-center gap-3"
             >
               <Download size={18} />
               Crop Image
             </button>
             <button
               onClick={() => { setImage(null); handlePresetChange(undefined); }}
               className="btn-secondary w-full"
             >
               Discard Image
             </button>
          </div>

          <div className="p-4 bg-blue-500/5 border border-blue-500/20 rounded-xl">
             <div className="flex gap-3 text-accent mb-2">
                <ImageIcon size={16} />
                <span className="text-[10px] font-bold uppercase tracking-widest">Processing Node</span>
             </div>
             <p className="text-[10px] text-text-muted leading-relaxed">
               Cropping is executed serverlessly within your browser memory. No data is transmitted to external storage.
             </p>
          </div>
        </div>
      </div>
    </div>
  );
}
