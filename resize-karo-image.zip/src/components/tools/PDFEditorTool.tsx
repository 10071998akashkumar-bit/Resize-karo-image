import React, { useState, useRef } from 'react';
import { PDFDocument } from 'pdf-lib';
import { FileText, Trash2, ArrowUp, ArrowDown, Download, FilePlus, Layers, FileDigit, Plus, RefreshCw } from 'lucide-react';
import { useDropzone, DropzoneOptions } from 'react-dropzone';

interface PDFPage {
  pdfIndex: number;
  pageIndex: number;
  id: string;
}

export function PDFEditorTool() {
  const [pdfs, setPdfs] = useState<{ name: string; doc: PDFDocument; file: File }[]>([]);
  const [allPages, setAllPages] = useState<PDFPage[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onDrop = async (acceptedFiles: File[]) => {
    setError(null);
    setIsProcessing(true);
    try {
      const newPdfs = [...pdfs];
      const newPages = [...allPages];

      for (const file of acceptedFiles) {
        if (file.type !== 'application/pdf') continue;

        const arrayBuffer = await file.arrayBuffer();
        const pdfDoc = await PDFDocument.load(arrayBuffer, { ignoreEncryption: true });
        const pdfIndex = newPdfs.length;
        
        newPdfs.push({ name: file.name, doc: pdfDoc, file });
        
        const pageCount = pdfDoc.getPageCount();
        for (let i = 0; i < pageCount; i++) {
          newPages.push({
            pdfIndex,
            pageIndex: i,
            id: `${pdfIndex}-${i}-${Math.random().toString(36).substr(2, 9)}`
          });
        }
      }

      setPdfs(newPdfs);
      setAllPages(newPages);
    } catch (err) {
      console.error(err);
      setError('Failed to process one or more PDF files.');
    } finally {
      setIsProcessing(false);
    }
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'application/pdf': ['.pdf'] }
  } as unknown as DropzoneOptions);

  const movePage = (index: number, direction: 'up' | 'down') => {
    const newPages = [...allPages];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    
    if (targetIndex < 0 || targetIndex >= newPages.length) return;
    
    const [moved] = newPages.splice(index, 1);
    newPages.splice(targetIndex, 0, moved);
    setAllPages(newPages);
  };

  const deletePage = (index: number) => {
    setAllPages(prev => prev.filter((_, i) => i !== index));
  };

  const exportPDF = async () => {
    if (allPages.length === 0) return;
    setIsProcessing(true);
    try {
      const mergedPdf = await PDFDocument.create();
      
      for (const pageInfo of allPages) {
        const sourcePdf = pdfs[pageInfo.pdfIndex].doc;
        const [copiedPage] = await mergedPdf.copyPages(sourcePdf, [pageInfo.pageIndex]);
        mergedPdf.addPage(copiedPage);
      }

      const pdfBytes = await mergedPdf.save();
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = 'edited_document.pdf';
      link.click();
      
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error(err);
      setError('Failed to export PDF.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="flex flex-col h-full items-center max-w-5xl mx-auto w-full">
      <div className="text-center mb-12">
        <h2 className="hero-heading uppercase tracking-tight">PDF Nexus<br/>Editor<span className="serif-italic">&copy;</span></h2>
        <p className="text-text-muted mt-4 max-w-lg mx-auto text-sm leading-relaxed opacity-80">
          Advanced node-based PDF manipulation. Merge, reorder, and excise pages with structural integrity auditing.
        </p>
      </div>

      {allPages.length === 0 ? (
        <div 
          {...getRootProps()}
          className={`w-full glass-panel p-20 flex flex-col items-center justify-center cursor-pointer transition-all duration-500 group relative overflow-hidden text-center border-dashed ${
            isDragActive ? 'border-accent bg-accent/10 border-2' : 'hover:border-accent hover:bg-accent/5'
          }`}
        >
          <input {...getInputProps()} />
          <div className="flex gap-4 mb-8">
            <div className="w-16 h-16 glass-panel-inner flex items-center justify-center text-accent group-hover:scale-110 active:scale-95 transition-all duration-500 bg-white/5 border-white/10 ring-8 ring-accent/5">
              <Layers size={24} />
            </div>
            <div className="w-16 h-16 glass-panel-inner flex items-center justify-center text-accent group-hover:scale-110 active:scale-95 transition-all duration-500 bg-white/5 border-white/10 ring-8 ring-accent/5 delay-75">
              <Plus size={24} />
            </div>
          </div>
          <h3 className="text-xl font-bold text-white mb-2 uppercase tracking-[0.2em]">Initialize PDF Stream</h3>
          <p className="text-text-dim text-[10px] font-mono tracking-widest uppercase">Drag & Drop or Click to Load Objects</p>
          
          {error && (
            <div className="mt-8 px-4 py-2 bg-red-500/10 border border-red-500/20 text-red-500 text-[10px] uppercase font-bold tracking-widest rounded-full animate-pulse">
              {error}
            </div>
          )}
        </div>
      ) : (
        <div className="w-full glass-panel p-8">
          <div className="flex items-center justify-between mb-10 pb-6 border-b border-white/5">
             <div className="flex items-center gap-6">
                <div className="hidden sm:flex w-14 h-14 bg-accent/20 rounded-2xl items-center justify-center text-accent border border-accent/20">
                   <FileDigit size={28} />
                </div>
                <div>
                   <h3 className="text-2xl font-bold text-white tracking-tight leading-none mb-2">{allPages.length} Pages Active</h3>
                   <p className="text-text-dim text-[10px] font-mono uppercase tracking-[0.2em]">{pdfs.length} Linked Source Documents</p>
                </div>
             </div>
             
             <div className="flex gap-3">
                <button 
                  {...getRootProps()}
                  className="btn-secondary group px-6 flex items-center gap-2"
                >
                  <input {...getInputProps()} />
                  <FilePlus size={16} className="text-accent group-hover:scale-110 transition-transform" />
                  <span className="hidden sm:inline">Add Files</span>
                </button>
             </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {allPages.map((page, idx) => (
              <div key={page.id} className="glass-panel-inner p-4 flex items-center gap-4 group transition-all duration-300 hover:bg-white/5 hover:border-accent/40 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button 
                      onClick={() => deletePage(idx)}
                      className="text-text-dim hover:text-red-500 transition-colors p-1"
                    >
                      <Trash2 size={14} />
                    </button>
                </div>

                <div className="w-12 h-16 flex items-center justify-center bg-bg-base border border-white/5 rounded relative flex-shrink-0">
                   <FileText size={24} className="text-accent/40" />
                   <span className="absolute bottom-1 right-1 text-[8px] font-mono text-white/40">{idx + 1}</span>
                </div>

                <div className="flex-1 min-w-0 pr-6">
                   <div className="text-[10px] font-bold text-text-dim uppercase tracking-widest mb-1 truncate">
                     {pdfs[page.pdfIndex].name}
                   </div>
                   <div className="text-xs font-semibold text-white/80">
                     Original Page: {page.pageIndex + 1}
                   </div>
                </div>

                <div className="flex flex-col gap-2">
                   <button 
                     onClick={() => movePage(idx, 'up')}
                     disabled={idx === 0}
                     className="text-text-dim hover:text-white disabled:opacity-0 transition-all p-1 glass-panel-inner"
                   >
                     <ArrowUp size={14} />
                   </button>
                   <button 
                     onClick={() => movePage(idx, 'down')}
                     disabled={idx === allPages.length - 1}
                     className="text-text-dim hover:text-white disabled:opacity-0 transition-all p-1 glass-panel-inner"
                   >
                     <ArrowDown size={14} />
                   </button>
                </div>
              </div>
            ))}
          </div>

          <div className="flex flex-col sm:flex-row gap-4 pt-10 border-t border-white/5">
             <button
               onClick={exportPDF}
               disabled={isProcessing}
               className="btn-primary flex-1 flex items-center justify-center gap-3 relative overflow-hidden"
             >
               {isProcessing ? (
                 <>
                   <RefreshCw className="animate-spin" size={18} />
                   Reconfiguring Node...
                 </>
               ) : (
                 <>
                   <Download size={18} />
                   Execute Final PDF Manifest
                 </>
               )}
             </button>
             <button
               onClick={() => { setPdfs([]); setAllPages([]); }}
               className="btn-secondary sm:w-48 uppercase tracking-widest text-[10px] font-bold"
             >
               Purge Cache
             </button>
          </div>
        </div>
      )}
    </div>
  );
}
