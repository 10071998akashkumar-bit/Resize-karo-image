import { 
  Maximize, FileDigit, PenTool, Sparkles, Layers, FileImage, Download, Scissors, Home as HomeIcon, Settings, MessageSquare, ShieldCheck as AdminIcon
} from 'lucide-react';
import type { ToolType } from '../App';
import React from 'react';

interface SidebarProps {
  activeTool: ToolType;
  onToolChange: (tool: ToolType) => void;
}

export function Sidebar({ activeTool, onToolChange }: SidebarProps) {
  return (
    <aside className="hidden md:flex flex-col w-72 bg-transparent h-full py-8 px-6 shrink-0 z-40 overflow-hidden">
      <div className="glass-panel p-6 h-full flex flex-col gap-2 overflow-y-auto custom-scrollbar">
        <div className="px-2 mb-4">
           <span className="text-[10px] font-bold text-text-dim tracking-widest uppercase opacity-70">Core Tools</span>
        </div>
        
        <SidebarLink
          icon={<HomeIcon size={20} />}
          label="Resize Karo Home"
          active={activeTool === 'home'}
          onClick={() => onToolChange('home')}
        />
        <SidebarLink
          icon={<Maximize size={20} />}
          label="Resize Image"
          active={activeTool === 'resize'}
          onClick={() => onToolChange('resize')}
        />
        <SidebarLink
          icon={<Scissors size={20} />}
          label="Crop Image"
          active={activeTool === 'crop'}
          onClick={() => onToolChange('crop')}
        />
        <SidebarLink
          icon={<Layers size={20} />}
          label="PDF Editor"
          active={activeTool === 'pdfeditor'}
          onClick={() => onToolChange('pdfeditor')}
        />
        <SidebarLink
          icon={<FileDigit size={20} />}
          label="Convert PDF"
          active={activeTool === 'pdf2img'}
          onClick={() => onToolChange('pdf2img')}
        />
        <SidebarLink
          icon={<Download size={20} />}
          label="Document Exporter"
          active={activeTool === 'img2pdf'}
          onClick={() => onToolChange('img2pdf')}
        />
        <SidebarLink
          icon={<PenTool size={20} />}
          label="Sign Asset"
          active={activeTool === 'signature'}
          onClick={() => onToolChange('signature')}
        />

        <div className="my-6 h-px bg-white/5" />

        <div className="px-2 mb-4">
           <span className="text-[10px] font-bold text-text-dim tracking-widest uppercase opacity-70">AI Laboratory</span>
        </div>
        
        <SidebarLink
          icon={<Layers size={20} />}
          label="Background Removal"
          active={activeTool === 'removebg'}
          onClick={() => onToolChange('removebg')}
          isBeta
        />
        <SidebarLink
          icon={<Sparkles size={20} />}
          label="Quality Enhancer"
          active={activeTool === 'quality'}
          onClick={() => onToolChange('quality')}
          isBeta
        />

        <div className="mt-auto pt-6 flex flex-col gap-2">
          <SidebarLink
            icon={<MessageSquare size={20} />}
            label="Feedback Hub"
            active={activeTool === 'feedback'}
            onClick={() => onToolChange('feedback')}
          />
          <SidebarLink
            icon={<AdminIcon size={20} />}
            label="Admin Hub"
            active={activeTool === 'profile'}
            onClick={() => onToolChange('profile')}
          />
        </div>
      </div>
    </aside>
  );
}

function SidebarLink({ icon, label, active, onClick, isBeta }: { icon: React.ReactNode, label: string, active: boolean, onClick: () => void, isBeta?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={`group flex items-center gap-4 transition-all duration-300 rounded-2xl p-4 w-full text-left relative ${
        active 
          ? 'bg-accent text-white shadow-[0_0_20px_rgba(59,130,246,0.5)]' 
          : 'text-text-muted hover:text-white hover:bg-white/5'
      }`}
    >
      <div className={`transition-transform duration-300 ${active ? 'scale-110' : 'group-hover:scale-110 opacity-70 group-hover:opacity-100'}`}>
        {icon}
      </div>
      <span className="text-sm font-bold tracking-tight">
        {label}
      </span>
      {isBeta && !active && (
        <span className="absolute right-4 top-1/2 -translate-y-1/2 text-[8px] bg-accent/20 text-accent px-1.5 py-0.5 rounded-full font-bold">
          BETA
        </span>
      )}
    </button>
  );
}
