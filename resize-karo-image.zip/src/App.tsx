import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { TopNav } from './components/TopNav';
import { Sidebar } from './components/Sidebar';
import { ResizeTool } from './components/tools/ResizeTool';
import { SignatureTool } from './components/tools/SignatureTool';
import { ImageToPdfTool } from './components/tools/ImageToPdfTool';
import { CropTool } from './components/tools/CropTool';
import { PDFEditorTool } from './components/tools/PDFEditorTool';
import { PdfToImageTool } from './components/tools/PdfToImageTool';
import { CompressPdfTool } from './components/tools/CompressPdfTool';
import { RemoveBgTool } from './components/tools/RemoveBgTool';
import { QualityBoostTool } from './components/tools/QualityBoostTool';
import { ProfileTool } from './components/tools/ProfileTool';
import { FeedbackTool } from './components/tools/FeedbackTool';
import { Home } from './components/Home';
import { ComingSoonTool } from './components/tools/ComingSoonTool';

export type ToolType = 'home' | 'resize' | 'signature' | 'img2pdf' | 'pdf2img' | 'removebg' | 'blur' | 'mergepdf' | 'compresspdf' | 'crop' | 'quality' | 'convert' | 'pdfeditor' | 'profile' | 'feedback';

export default function App() {
  const [activeTool, setActiveTool] = useState<ToolType>('home');
  const [preset, setPreset] = useState<string | null>(null);
  
  // Need to force unmount/remount tool when preset changes to re-initialize state
  const toolKey = `${activeTool}-${preset || 'none'}`;

  const handleToolChange = (tool: ToolType, selectedPreset?: string) => {
    setActiveTool(tool);
    if (selectedPreset) {
      setPreset(selectedPreset);
    } else {
      setPreset(null);
    }
    // Mobile: close sidebar logic could go here
  };

  const renderTool = () => {
    switch (activeTool) {
      case 'home':
        return <Home onToolChange={handleToolChange} />;
      case 'resize':
        return <ResizeTool preset={preset} />;
      case 'signature':
        return <SignatureTool />;
      case 'img2pdf':
        return <ImageToPdfTool />;
      case 'crop':
        return <CropTool />;
      case 'pdfeditor':
        return <PDFEditorTool />;
      case 'pdf2img':
        return <PdfToImageTool />;
      case 'compresspdf':
        return <CompressPdfTool />;
      case 'mergepdf':
        return <PDFEditorTool />; // Using the sophisticated editor for merge
      case 'removebg':
        return <RemoveBgTool />;
      case 'quality':
        return <QualityBoostTool />;
      case 'profile':
        return <ProfileTool />;
      case 'feedback':
        return <FeedbackTool />;
      default:
        return <ComingSoonTool toolId={activeTool} onBack={() => setActiveTool('home')} />;
    }
  };

  return (
    <div className="min-h-screen bg-bg-base text-text-main font-sans overflow-hidden flex flex-col relative w-full selection:bg-accent selection:text-white">
      {/* Background Decorative Elements */}
      <div className="visual-element opacity-50" />
      <div className="absolute top-1/2 left-1/4 w-96 h-96 bg-white/[0.015] rounded-full blur-[140px] pointer-events-none select-none" />

      <TopNav activeTool={activeTool} onToolChange={handleToolChange} />
      
      <main className="flex-1 flex overflow-hidden z-10 w-full relative pt-[72px]">
        <Sidebar activeTool={activeTool} onToolChange={handleToolChange} />
        
        <div className="flex-1 overflow-y-auto px-6 py-10 md:px-16 custom-scrollbar flex flex-col items-center">
          <AnimatePresence mode="wait">
            <motion.div
              key={toolKey}
              initial={{ opacity: 0, scale: 0.98, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 1.02, y: -20 }}
              transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
              className="w-full max-w-6xl"
            >
              {renderTool()}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Global Meta Footer Overlay */}
      <div className="fixed bottom-0 left-0 right-0 pointer-events-none md:flex justify-between px-12 py-4 text-[10px] text-text-dim uppercase tracking-[0.2em] bg-gradient-to-t from-bg-base to-transparent hidden z-30">
        <div className="flex items-center gap-4 opacity-50">
          <span>&copy; 2024 RESIZE KARO IMAGE</span>
          <span className="w-1 h-1 bg-text-dim rounded-full" />
          <span>EST. 2024</span>
        </div>
        <div className="opacity-50">PRODUCTION v1.0.42</div>
      </div>
    </div>
  );
}
