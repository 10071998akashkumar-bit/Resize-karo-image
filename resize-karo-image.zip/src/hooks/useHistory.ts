import { useState, useCallback } from 'react';

export function useHistory<T>(initialState: T) {
  const [history, setHistory] = useState<T[]>([initialState]);
  const [currentIndex, setCurrentIndex] = useState(0);

  const setState = useCallback((newState: T | ((prev: T) => T), replace = false) => {
    setHistory(prev => {
      const current = prev[currentIndex];
      const resolvedState = typeof newState === 'function' 
        ? (newState as (prev: T) => T)(current) 
        : newState;

      if (JSON.stringify(resolvedState) === JSON.stringify(current)) {
        return prev;
      }

      if (replace) {
        const newHistory = [...prev];
        newHistory[currentIndex] = resolvedState;
        return newHistory;
      }

      const newHistory = prev.slice(0, currentIndex + 1);
      newHistory.push(resolvedState);
      
      if (newHistory.length > 50) {
        newHistory.shift();
        return [...newHistory];
      } else {
        setCurrentIndex(newHistory.length - 1);
        return [...newHistory];
      }
    });
  }, [currentIndex]);

  const undo = useCallback(() => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
    }
  }, [currentIndex]);

  const redo = useCallback(() => {
    if (currentIndex < history.length - 1) {
      setCurrentIndex(prev => prev + 1);
    }
  }, [currentIndex, history.length]);

  return {
    state: history[currentIndex],
    setState,
    undo,
    redo,
    canUndo: currentIndex > 0,
    canRedo: currentIndex < history.length - 1,
    resetHistory: (newState: T) => {
      setHistory([newState]);
      setCurrentIndex(0);
    }
  };
}
